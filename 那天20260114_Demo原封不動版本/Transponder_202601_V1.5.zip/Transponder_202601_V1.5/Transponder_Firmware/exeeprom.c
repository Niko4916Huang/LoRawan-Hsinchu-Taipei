#include "exeeprom.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ssi.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/ssi.h"

// ============================================================================
// [指令集定義] (Datasheet Table 4 [cite: 277])
// ============================================================================
#define CMD_WREN  0x06  // Write Enable
#define CMD_WRDI  0x04  // Write Disable
#define CMD_RDSR  0x05  // Read Status Register
#define CMD_WRSR  0x01  // Write Status Register
#define CMD_READ  0x03  // Read from Memory Array
#define CMD_WRITE 0x02  // Write to Memory Array

// Status Register Bits
#define SR_WIP    0x01  // Write In Progress

// ============================================================================
// [內部 Helper 函式]
// ============================================================================

// CS 控制: Low = Select, High = Deselect
static void _CS_Low(void) {
    MAP_GPIOPinWrite(EX_CS_PORT, EX_CS_PIN, 0);
}

static void _CS_High(void) {
    MAP_GPIOPinWrite(EX_CS_PORT, EX_CS_PIN, EX_CS_PIN);
}

// SPI 收發一個 Byte
static uint8_t _SPI_Transfer(uint8_t data) {
    uint32_t rxtmp;
    // 寫入 FIFO
    MAP_SSIDataPut(EX_SSI_BASE, (uint32_t)data);
    // 等待傳輸完成
    while(MAP_SSIBusy(EX_SSI_BASE));
    // 讀取 FIFO
    MAP_SSIDataGet(EX_SSI_BASE, &rxtmp);
    return (uint8_t)(rxtmp & 0xFF);
}

// 等待寫入完成 (WIP Polling)
// 當寫入指令送出後，EEPROM 需要時間寫入 Flash (tW = 4ms [cite: 33])
static void _EEPROM_WaitWIP(void) {
    uint8_t status;
    do {
        _CS_Low();
        _SPI_Transfer(CMD_RDSR); // 發送讀取狀態暫存器指令
        status = _SPI_Transfer(0xFF); // 發送 Dummy 讀回狀態
        _CS_High();
    } while (status & SR_WIP); // 如果 Bit 0 (WIP) 是 1，繼續等待
}

// 啟用寫入 (Write Enable)
// 每次 WRITE 前都必須發送 WREN 指令 [cite: 201, 294]
static void _EEPROM_WriteEnable(void) {
    _CS_Low();
    _SPI_Transfer(CMD_WREN);
    _CS_High();
}

// ============================================================================
// [API 實作]
// ============================================================================

void EEPROM_Init(void) {
    // 1. 啟用周邊 (SSI3, GPIO Q, F, P)
    MAP_SysCtlPeripheralEnable(EX_SSI_PERIPH);
    MAP_SysCtlPeripheralEnable(EX_GPIO_PERIPH); // Port Q (SPI)
    MAP_SysCtlPeripheralEnable(EX_HOLD_PERIPH); // Port F (HOLD)
    MAP_SysCtlPeripheralEnable(EX_WP_PERIPH);   // Port P (WP)
    // EX_CS_PERIPH 也是 Port Q，上面已經 Enable 過了，但為了安全:
    // MAP_SysCtlPeripheralEnable(EX_CS_PERIPH); 

    // 等待周邊就緒
    while(!MAP_SysCtlPeripheralReady(EX_SSI_PERIPH));
    while(!MAP_SysCtlPeripheralReady(EX_GPIO_PERIPH));
    while(!MAP_SysCtlPeripheralReady(EX_HOLD_PERIPH));
    while(!MAP_SysCtlPeripheralReady(EX_WP_PERIPH));

    // 2. 配置 Control Pins (CS, HOLD, WP)
    
    // Config HOLD (PF2) -> Output High (Disable Hold)
    MAP_GPIOPinTypeGPIOOutput(EX_HOLD_PORT, EX_HOLD_PIN);
    MAP_GPIOPinWrite(EX_HOLD_PORT, EX_HOLD_PIN, EX_HOLD_PIN);

    // Config WP (PP1) -> Output High (Enable Write)
    // WP low 會保護 Status Register [cite: 322]，一般操作拉 High
    MAP_GPIOPinTypeGPIOOutput(EX_WP_PORT, EX_WP_PIN);
    MAP_GPIOPinWrite(EX_WP_PORT, EX_WP_PIN, EX_WP_PIN);

    // Config CS (PQ1) -> Output High (Deselect)
    MAP_GPIOPinTypeGPIOOutput(EX_CS_PORT, EX_CS_PIN);
    _CS_High();

    // 3. 配置 SPI 腳位 (PQ0, PQ2, PQ3)
    MAP_GPIOPinConfigure(EX_CFG_CLK);
    MAP_GPIOPinConfigure(EX_CFG_TX);
    MAP_GPIOPinConfigure(EX_CFG_RX);
    MAP_GPIOPinTypeSSI(EX_GPIO_PORT, EX_PIN_CLK | EX_PIN_TX | EX_PIN_RX);

    // 4. 配置 SSI
    // M95040 支援 SPI Mode 0 (CPOL=0, CPHA=0) [cite: 158]
    // 頻率: Datasheet 支援 5MHz~20MHz [cite: 29-32]，這裡設 2MHz 保守起見
    MAP_SSIConfigSetExpClk(EX_SSI_BASE, g_ui32SysClock, SSI_FRF_MOTO_MODE_0,
                           SSI_MODE_MASTER, 2000000, 8);

    // 5. 啟用 SSI
    MAP_SSIEnable(EX_SSI_BASE);
    
    // 清空 RX FIFO 避免殘留數據
    uint32_t trash;
    while(MAP_SSIDataGetNonBlocking(EX_SSI_BASE, &trash));
}

int EEPROM_Read(uint16_t addr, uint8_t *pBuf, uint16_t len) {
    if (len == 0 || addr >= EEPROM_SIZE_BYTES) return -1;

    // 等待上一筆寫入完成 (安全起見)
    _EEPROM_WaitWIP();

    _CS_Low();

    // 建構指令 Byte
    // M95040 (4Kbit) 的第 9 位地址 (A8) 位於指令 byte 的 bit 3 [cite: 282, 396]
    // READ 指令基本是 0x03 (0000 0011)
    // 如果 addr > 255 (A8=1)，指令變成 0x0B (0000 1011)
    uint8_t cmd = CMD_READ;
    if (addr & 0x100) {
        cmd |= 0x08; // Set bit 3
    }
    _SPI_Transfer(cmd);

    // 發送低 8 位地址
    _SPI_Transfer((uint8_t)(addr & 0xFF));

    // 連續讀取資料
    for (uint16_t i = 0; i < len; i++) {
        pBuf[i] = _SPI_Transfer(0xFF); // 發送 Dummy byte 以推入 Clock
    }

    _CS_High();
    return 0;
}

int EEPROM_Write(uint16_t addr, uint8_t *pBuf, uint16_t len) {
    if (len == 0 || addr >= EEPROM_SIZE_BYTES) return -1;

    uint16_t bytesWritten = 0;

    // 必須處理 Page Boundary (跨頁寫入)
    // M95040 Page Size = 16 Bytes [cite: 23]
    while (bytesWritten < len) {
        
        // 1. 計算本頁剩餘空間
        uint16_t offsetInPage = addr % EEPROM_PAGE_SIZE;
        uint16_t bytesInPage = EEPROM_PAGE_SIZE - offsetInPage;
        uint16_t bytesLeft = len - bytesWritten;
        uint16_t chunkLen = (bytesLeft < bytesInPage) ? bytesLeft : bytesInPage;

        // 2. 啟用寫入 (WREN)
        // 每次 CS 拉高後，WREN 會被重置，所以每寫一頁都要重送一次 [cite: 294]
        _EEPROM_WaitWIP(); // 確保上一頁寫完
        _EEPROM_WriteEnable();

        // 3. 開始寫入序列
        _CS_Low();

        // 建構指令 Byte (處理 A8 bit) [cite: 282, 429]
        // WRITE 指令基本是 0x02 (0000 0010)
        // 如果 A8=1，指令變成 0x0A (0000 1010)
        uint8_t cmd = CMD_WRITE;
        if (addr & 0x100) {
            cmd |= 0x08;
        }
        _SPI_Transfer(cmd);

        // 發送低 8 位地址
        _SPI_Transfer((uint8_t)(addr & 0xFF));

        // 發送資料
        for (uint16_t i = 0; i < chunkLen; i++) {
            _SPI_Transfer(pBuf[bytesWritten + i]);
        }

        // 4. 結束寫入
        // CS 拉高會觸發內部的 Self-timed Write Cycle [cite: 430, 449]
        _CS_High();

        // 5. 更新計數器
        addr += chunkLen;
        bytesWritten += chunkLen;
    }

    // 最後等待一下確保寫入完成
    _EEPROM_WaitWIP();

    return 0;
}
