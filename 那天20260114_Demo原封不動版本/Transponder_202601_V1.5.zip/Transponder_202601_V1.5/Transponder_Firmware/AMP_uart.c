/* AMP_uart.c
 *
 * 封包導向架構（Solution B，修正版）：
 *
 * - Timer0A：每 100ms 只負責送一次 COMMAND[g_currentCmdIndex]
 *
 * - UART1 RX 中斷：在資料流中尋找封包：
 *     header pattern：
 *         [0]     = 0xBE
 *         [1..5]  = COMMAND[g_currentCmdIndex][1..5]
 *       也就是： 0xBE + COMMAND 的第 2~6 個 byte
 *
 * - 一旦找到這 6 bytes 依序出現，就視為正確封包開頭，
 *   從 0xBE 開始算起，一共收集 UARTLOG_VALID_LEN (=191) 個 byte。
 *
 * - 收滿 191 bytes 後：
 *     - 將這 191 bytes 寫入 frame buffer，
 *     - 後面補 0 到 UARTLOG_FRAME_SIZE (=200) bytes，
 *     - 再寫入一維陣列 g_uartLogBuf 對應的 frame 位置。
 *
 * - 不再使用 01 00 作為尾巴判斷。
 */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "AMP_uart.h"
#include "utils/uartstdio.h"   // 若需要 UARTprintf，就保留

/* ---------------------
 *  UART 指令列表 (9 x UARTLOG_CMD_LEN bytes)
 * --------------------- */
const uint8_t COMMAND[UARTLOG_CMD_COUNT][UARTLOG_CMD_LEN] =
{
    {0x10, 0x08, 0x11, 0x11, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x03, 0xB0, 0x03, 0x01, 0x01, 0x00},
    {0x10, 0x08, 0x22, 0x22, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x03, 0xB0, 0x03, 0x02, 0x90, 0x00},
    {0x10, 0x08, 0x33, 0x33, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x03, 0xB0, 0x03, 0x02, 0xA0, 0x00},
    {0x10, 0x08, 0x44, 0x44, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x05, 0xB0, 0x03, 0x21, 0x01, 0x00},
    {0x10, 0x08, 0x55, 0x55, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x05, 0xB0, 0x03, 0x21, 0x02, 0x00},
    {0x10, 0x08, 0x66, 0x66, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x05, 0xB0, 0x03, 0x21, 0x03, 0x00},
    {0x10, 0x08, 0x77, 0x77, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x05, 0xB0, 0x03, 0x21, 0x11, 0x00},
    {0x10, 0x08, 0x88, 0x88, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x05, 0xB0, 0x03, 0x21, 0x12, 0x00},
    {0x10, 0x08, 0x99, 0x99, 0x9A, 0x06, 0x09, 0x08, 0x01, 0x12, 0x05, 0x05, 0xB0, 0x03, 0x21, 0x13, 0x00},
};

/* 一維陣列：每個 frame 佔 UARTLOG_FRAME_SIZE (=200) bytes */
static uint8_t g_uartLogBuf[UARTLOG_TOTAL_BYTES];

/* 目前寫入的 frame index（0 ~ UARTLOG_MAX_FRAMES-1，環形）*/
static volatile uint32_t g_currFrameIndex = 0;

/* 累計已經寫入幾個 frame（可當作計數器用） */
static volatile uint32_t g_frameCount = 0;

/* 統計用 */
volatile uint32_t g_totalBytesRx = 0;
volatile uint32_t g_timer0a_cnt  = 0;

/* 目前選擇要送出的 command index（0~8） */
static volatile uint32_t g_currentCmdIndex = 0;

/* ---------- header / 長度定義 ---------- */
/* 固定第一個 byte = 0xBE */
//static const uint8_t s_headerFirstByte = 0xBE;

/* ---------- header / 長度定義 ---------- */
static const uint8_t s_headerFirstBytes[] = {
    0xBE,
    0xCA,
    0xC8
};

#define HEADER_FIRST_BYTE_COUNT \
    (sizeof(s_headerFirstBytes) / sizeof(s_headerFirstBytes[0]))




/* 實際有效資料長度（從 0xBE 開始算） */
#define UARTLOG_VALID_LEN   191    /* 收集 191 bytes，再補 0 到 200 */

/* RX 狀態機 */
typedef enum
{
    UARTLOG_RX_STATE_SEARCH_HEADER = 0,  /* 找 header (0xBE + COMMAND[index][1..5]) */
    UARTLOG_RX_STATE_COLLECT_FRAME       /* 收集剩下的 frame（直到 VALID_LEN=191 bytes） */
} UartLog_RxState_t;

/* 收封包用的 buffer 與狀態 */
static volatile UartLog_RxState_t g_rxState = UARTLOG_RX_STATE_SEARCH_HEADER;
static volatile uint8_t  g_rxFrameBuf[UARTLOG_FRAME_SIZE];
static volatile uint32_t g_rxIndex = 0;

/* 搜尋 header 用的 6-byte window
 * 需搭配 AMP_uart.h 裡：
 *   #define UARTLOG_HEADER_LEN   6
 */
static uint8_t  g_headerWindow[UARTLOG_HEADER_LEN];
static uint32_t g_headerCount = 0;

static inline bool IsValidHeaderFirstByte(uint8_t b)
{
    uint32_t i;
	for (i = 0; i < HEADER_FIRST_BYTE_COUNT; i++)
    {
        if (b == s_headerFirstBytes[i])
            return true;
    }
    return false;
}


/* 對外：重設整體 logger 狀態 */
void UartLog_Reset(void)
{
    uint32_t i;

    IntMasterDisable();

    for (i = 0; i < UARTLOG_TOTAL_BYTES; i++)
    {
        g_uartLogBuf[i] = 0;
    }

    g_currFrameIndex  = 0;
    g_frameCount      = 0;
    g_totalBytesRx    = 0;
    g_timer0a_cnt     = 0;
    g_currentCmdIndex = 0;

    /* RX 狀態機重設 */
    g_rxState      = UARTLOG_RX_STATE_SEARCH_HEADER;
    g_rxIndex      = 0;
    g_headerCount  = 0;
    memset((void*)g_rxFrameBuf,   0, sizeof(g_rxFrameBuf));
    memset((void*)g_headerWindow, 0, sizeof(g_headerWindow));

    IntMasterEnable();
}

/* 對外 API：回傳一維陣列指標 */
const uint8_t* UartLog_GetBuffer(void)
{
    return (const uint8_t*)g_uartLogBuf;
}

/* 對外 API：回傳已寫入 frame 數 */
uint32_t UartLog_GetFrameCount(void)
{
    return g_frameCount;
}

/* 初始化：
 * - UART1 (Rx/Tx)
 * - Timer0A 每 100ms 產生一次中斷，只負責送 command
 */
void UartLog_Init(uint32_t sysClkHz)
{
    /* 啟動 UART1 與 GPIO */
    SysCtlPeripheralEnable(UARTLOG_UART_PERIPH);
    SysCtlPeripheralEnable(UARTLOG_GPIO_PERIPH);
    while (!SysCtlPeripheralReady(UARTLOG_UART_PERIPH));
    while (!SysCtlPeripheralReady(UARTLOG_GPIO_PERIPH));

    /* 設定 GPIO 為 UART 功能 */
    GPIOPinConfigure(UARTLOG_GPIO_PIN_CFG_RX);
    GPIOPinConfigure(UARTLOG_GPIO_PIN_CFG_TX);
    GPIOPinTypeUART(UARTLOG_GPIO_BASE, UARTLOG_GPIO_PINS);

    /* UART1 設定：8N1, 指定鮑率 */
    UARTConfigSetExpClk(UARTLOG_UART_BASE,
                        sysClkHz,
                        UARTLOG_BAUD_RATE,
                        UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE);

    /* 清除並啟用 UART1 RX 中斷 */
    UARTIntDisable(UARTLOG_UART_BASE, 0xFFFFFFFF);
    UARTIntClear(UARTLOG_UART_BASE, 0xFFFFFFFF);
    UARTIntEnable(UARTLOG_UART_BASE, UART_INT_RX | UART_INT_RT);

    /* 啟用 NVIC 中的 UART1 中斷 */
    IntEnable(INT_UART1);

    /* Logger 狀態歸零 */
    UartLog_Reset();

    /* 設定 Timer0A 為 100ms 週期中斷（period = sysClkHz / 10） */
    SysCtlPeripheralEnable(UARTLOG_TIMER_PERIPH);
    while (!SysCtlPeripheralReady(UARTLOG_TIMER_PERIPH));

    TimerDisable(UARTLOG_TIMER_BASE, TIMER_A);
    TimerConfigure(UARTLOG_TIMER_BASE, TIMER_CFG_PERIODIC);

    uint32_t periodTicks = sysClkHz / 10U;   /* 100ms = 0.1 s → sysClkHz / 10 */
    TimerLoadSet(UARTLOG_TIMER_BASE, TIMER_A, periodTicks - 1U);

    TimerIntDisable(UARTLOG_TIMER_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntClear(UARTLOG_TIMER_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntEnable(UARTLOG_TIMER_BASE, TIMER_TIMA_TIMEOUT);

    IntEnable(INT_TIMER0A);

    TimerEnable(UARTLOG_TIMER_BASE, TIMER_A);

    /* 全域中斷建議在 main() 裡呼叫 IntMasterEnable() */
}

/* Timer0A 每 100ms 進來一次：
 * - 只負責送出目前選擇的 command
 */
void Timer0AIntHandler(void)
{
    TimerIntClear(UARTLOG_TIMER_BASE, TIMER_TIMA_TIMEOUT);
    g_timer0a_cnt++;

    /* 每 100ms 送一次目前的 command */
    UartLog_SendCommand(g_currentCmdIndex);
}

/* 設定要送哪一組 COMMAND（0~8） */
void UartLog_SetCommandIndex(uint32_t index)
{
    if (index >= UARTLOG_CMD_COUNT)
    {
        /* 超出範圍直接忽略 */
        return;
    }
    g_currentCmdIndex = index;
}

/* 透過 UART1 送出一組 COMMAND[index]（blocking） */
void UartLog_SendCommand(uint32_t index)
{
    uint32_t i;
    const uint8_t* cmd;

    if (index >= UARTLOG_CMD_COUNT)
        return;

    cmd = COMMAND[index];

    for (i = 0; i < UARTLOG_CMD_LEN; i++)
    {
        UARTCharPut(UARTLOG_UART_BASE, cmd[i]);  // Blocking 送出
        // 若要 debug，可以順便在 console 印出：
        // UARTprintf("[TX CMD%u][%02u] %02X\r\n", index, i, cmd[i]);
    }
}

/* UART1 RX 中斷處理：
 * - SEARCH_HEADER：
 *     使用 6-byte sliding window，尋找：
 *        [0]    = 0xBE
 *        [1..5] = COMMAND[g_currentCmdIndex][1..5]
 * - 找到 header 後：
 *     把這 6 bytes 放入 g_rxFrameBuf[0..5]，接著收滿 UARTLOG_VALID_LEN=191 bytes
 * - 收滿 191 bytes 後：
 *     把 frame 按一維方式存入 g_uartLogBuf，後面補 0 到 200 bytes
 */
void UART1IntHandler(void)
{
    uint32_t status;
    int32_t ch;

    status = UARTIntStatus(UARTLOG_UART_BASE, true);
    UARTIntClear(UARTLOG_UART_BASE, status);

    while (UARTCharsAvail(UARTLOG_UART_BASE))
    {
        ch = UARTCharGetNonBlocking(UARTLOG_UART_BASE);
        if (ch < 0)
        {
            continue;
        }

        uint8_t b = (uint8_t)ch;
        g_totalBytesRx++;

        switch (g_rxState)
        {
        case UARTLOG_RX_STATE_SEARCH_HEADER:
        {
            /* 更新 header window (sliding) */
            if (g_headerCount < UARTLOG_HEADER_LEN)
            {
                g_headerWindow[g_headerCount++] = b;
            }
            else
            {
                /* 已滿 UARTLOG_HEADER_LEN bytes，往前滑動一格 */
                uint32_t i;
                for (i = 0; i < (UARTLOG_HEADER_LEN - 1U); i++)
                {
                    g_headerWindow[i] = g_headerWindow[i + 1U];
                }
                g_headerWindow[UARTLOG_HEADER_LEN - 1U] = b;
                g_headerCount = UARTLOG_HEADER_LEN;
            }

            /* 當 window 裡有 UARTLOG_HEADER_LEN (=6) bytes 時檢查：
             *   [0]    = 0xBE
             *   [1..5] = COMMAND[g_currentCmdIndex][1..5]
             */
            if (g_headerCount == UARTLOG_HEADER_LEN)
            {
                //if (g_headerWindow[0] == s_headerFirstByte)
					if (IsValidHeaderFirstByte(g_headerWindow[0]))
                {
                    bool matched = true;
                    uint32_t i;

                    /* 比對 COMMAND[目前 index][1..5] （第 2~6 個 byte） */
                    for (i = 0; i < 5U; i++)
                    {
                        /* window[1+i] 對應 COMMAND[index][1+i] */
                        if (g_headerWindow[1U + i] != COMMAND[g_currentCmdIndex][1U + i])
                        {
                            matched = false;
                            break;
                        }
                    }

                    if (matched)
                    {
                        /* 找到封包起點：window[0..5] 就是 frame[0..5] */
                        for (i = 0; i < UARTLOG_HEADER_LEN; i++)
                        {
                            g_rxFrameBuf[i] = g_headerWindow[i];
                        }
                        g_rxIndex = UARTLOG_HEADER_LEN;  // 下一個要寫入的位置

                        /* 進入收 frame 狀態 */
                        g_rxState = UARTLOG_RX_STATE_COLLECT_FRAME;

                        /* 下一次找新封包前重新計數 */
                        g_headerCount = 0;
                        memset((void*)g_headerWindow, 0, sizeof(g_headerWindow));
                    }
                }
            }
            break;
        }

        case UARTLOG_RX_STATE_COLLECT_FRAME:
        {
            /* 只收集到 UARTLOG_VALID_LEN=191 bytes，多的就不再寫進這個 frame */
            if (g_rxIndex < UARTLOG_VALID_LEN)
            {
                g_rxFrameBuf[g_rxIndex++] = b;

                /* 收滿 191 bytes → 結束 frame，補 0 到 200 */
                if (g_rxIndex >= UARTLOG_VALID_LEN)
                {
                    uint32_t i;

                    /* 後面補 0 到 UARTLOG_FRAME_SIZE (=200) bytes */
                    for (i = g_rxIndex; i < UARTLOG_FRAME_SIZE; i++)
                    {
                        g_rxFrameBuf[i] = 0;
                    }

                    /* 寫入一維陣列 */
                    uint32_t frameIndex = g_currFrameIndex;
                    uint32_t baseOffset = frameIndex * UARTLOG_FRAME_SIZE;

                    if (baseOffset < UARTLOG_TOTAL_BYTES)
                    {
                        memcpy(&g_uartLogBuf[baseOffset],
                               (const void*)g_rxFrameBuf,
                               UARTLOG_FRAME_SIZE);
                    }

                    /* 更新 frame index（環形）與總數 */
                    g_currFrameIndex++;
                    if (g_currFrameIndex >= UARTLOG_MAX_FRAMES)
                    {
                        g_currFrameIndex = 0;
                    }
                    g_frameCount++;

                    /* 重頭找下一個封包 */
                    g_rxIndex     = 0;
                    g_rxState     = UARTLOG_RX_STATE_SEARCH_HEADER;
                    g_headerCount = 0;
                    memset((void*)g_headerWindow, 0, sizeof(g_headerWindow));
                }
            }

            /* 若已經 g_rxIndex >= UARTLOG_VALID_LEN，
             * 代表本 frame 已經在上面處理完並 reset state，
             * 這裡就不再處理。
             */
            break;
        }

        default:
            /* 防護：強制 reset 狀態機 */
            g_rxState     = UARTLOG_RX_STATE_SEARCH_HEADER;
            g_rxIndex     = 0;
            g_headerCount = 0;
            memset((void*)g_headerWindow, 0, sizeof(g_headerWindow));
            break;

        } // end switch
    } // end while
}
