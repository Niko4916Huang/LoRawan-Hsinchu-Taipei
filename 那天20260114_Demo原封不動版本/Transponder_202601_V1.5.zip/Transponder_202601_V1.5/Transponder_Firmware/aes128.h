/*
 * aes128.h
 *
 * Minimal AES-128 implementation for LoRaWAN (Encryption only)
 * Supported Modes: ECB, CMAC, CTR
 */

#ifndef AES128_H_
#define AES128_H_

#include <stdint.h>
#include <stddef.h>

// AES Block Size is always 16 bytes
#define AES_BLOCK_SIZE 16
#define AES_KEY_SIZE   16

// ============================================================================
// Core AES Function (ECB Mode)
// ============================================================================

/**
 * @brief AES-128 ECB Block Encryption
 * * @param key    [in]  16-byte AES Key
 * @param input  [in]  16-byte Plaintext Block
 * @param output [out] 16-byte Ciphertext Block
 */
void AES128_ECB_encrypt(const uint8_t *key, const uint8_t *input, uint8_t *output);

// ============================================================================
// LoRaWAN Helper Modes (CMAC & CTR)
// ============================================================================

/**
 * @brief Calculate AES-CMAC (RFC 4493) - Used for MIC
 * * @param key    [in]  16-byte AES Key (NwkSKey or AppKey)
 * @param input  [in]  Pointer to the data to be authenticated
 * @param length [in]  Length of the input data in bytes
 * @param mic    [out] Output 4-byte MIC (First 4 bytes of the full CMAC)
 * Note: Standard CMAC is 16 bytes, but LoRaWAN uses first 4.
 * If you need full 16 bytes, pass a 16-byte buffer and cast.
 */
void AES128_CMAC(const uint8_t *key, const uint8_t *input, uint32_t length, uint8_t *mic);

/**
 * @brief AES-CTR Mode - Used for Payload Encryption/Decryption
 * * @param key    [in]  16-byte AES Key (AppSKey)
 * @param iv     [in]  16-byte Initialization Vector (Block A)
 * @param input  [in]  Pointer to the input data (Plaintext or Ciphertext)
 * @param length [in]  Length of the data
 * @param output [out] Pointer to the output buffer
 */
void AES128_CTR_Encrypt(const uint8_t *key, const uint8_t *iv, const uint8_t *input, uint16_t length, uint8_t *output);

#endif /* AES128_H_ */
