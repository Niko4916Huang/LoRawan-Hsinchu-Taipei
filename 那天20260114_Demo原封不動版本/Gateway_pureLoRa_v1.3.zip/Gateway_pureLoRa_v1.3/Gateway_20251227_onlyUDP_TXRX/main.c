//*****************************************************************************
//
// main.c - Integrated: UDP<->LoRa or UART1<->LoRa
//
//*****************************************************************************

//=============================================================================
//  ★ SYSTEM MODE SWITCH ★
//  0 = UDP Bridge Mode (UDP Packet <-> LoRa Transponder)
//  1 = UART1 Bridge Mode (UART1 <-> LoRa Transponder)
//  
//  Note: UART0 is ALWAYS used for Debug Logging.
//=============================================================================
#define SYSTEM_MODE  1  // <--- 修改這裡切換模式 (0 or 1)

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"

#include "driverlib/flash.h"
#include "driverlib/interrupt.h"
#include "driverlib/gpio.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h" 
#include "driverlib/pin_map.h"
#include "driverlib/fpu.h"

#include "utils/lwiplib.h"
#include "utils/ustdlib.h"
#include "utils/uartstdio.h"
#include "drivers/pinout.h"

#include "UDP.h"   // 自己的 UDP 模組

// --- Code B (LoRa) Includes ---
#include "sx1262_tm4c.h"

// 外部 UDP 接收函式
extern void UdpGetLastFrame250(uint8_t *pData, uint16_t *pLen);

//===========================
// SysTick / 優先權
//===========================
#define SYSTICKHZ               100
#define SYSTICKMS               (1000 / SYSTICKHZ)
#define SYSTICK_INT_PRIORITY    0x80
#define ETHERNET_INT_PRIORITY   0xC0

//===========================
// Packet Parameters
//===========================
#define PAYLOAD_LEN      250  // 統一資料長度
#define LORA_PKT_SIZE    255
#define RF_OFFSET        5
#define UART1_BAUDRATE   115200

// UDP Header Constants
#define UDP_HEADER_IP_LEN       10
#define UDP_HEADER_PORT_LEN     10
#define UDP_FRAME_LEN           250
#define UDP_TOTAL_LEN           (UDP_HEADER_IP_LEN + UDP_HEADER_PORT_LEN + UDP_FRAME_LEN)

const uint8_t RF_GARBAGE[RF_OFFSET] = {0x5A, 0xA5, 0x5A, 0xA5, 0x5A};


//*****************************************************************************
// 頻率管理 (Gateway 端)
//*****************************************************************************

// Enum 定義必須與 Node 端 (SX1262_tm4c.h / LoRa API.h) 一致
// 請確保你的驅動 .h 檔有包含以下新增的頻率定義!
/*
typedef enum {
    SX1262_RF_FREQ_204MHZ, // 用於 GW 接收 (US)
    SX1262_RF_FREQ_255MHZ,
    SX1262_RF_FREQ_257MHZ, // 用於 GW 發射 (DS)
    SX1262_RF_FREQ_490MHZ,
    SX1262_RF_FREQ_833MHZ
} SX1262_RfFreqSel_t;
*/

typedef struct {
    uint8_t             channel_id;    
    SX1262_RfFreqSel_t  freq_tx;       // Gateway TX (下行 DS)
    SX1262_RfFreqSel_t  freq_rx;       // Gateway RX (上行 US)
} GatewayChannelMap_t;

// ★★★ Gateway 頻率對照表 (與 Node 端鏡像對應) ★★★
// Node 的 TX(US) = Gateway 的 RX
// Node 的 RX(DS) = Gateway 的 TX
static const GatewayChannelMap_t g_GwChannelTable[] = {
    // Option |    GW TX (DS) Enum      |    GW RX (US) Enum
    {  0x05,    SX1262_RF_FREQ_257MHZ,      SX1262_RF_FREQ_204MHZ }, // 預設值
    {  0x06,    SX1262_RF_FREQ_257MHZ,      SX1262_RF_FREQ_204MHZ }, 
    {  0x07,    SX1262_RF_FREQ_833MHZ,      SX1262_RF_FREQ_204MHZ }, 
    {  0x08,    SX1262_RF_FREQ_833MHZ,      SX1262_RF_FREQ_204MHZ }, 
    {  0x09,    SX1262_RF_FREQ_490MHZ,      SX1262_RF_FREQ_490MHZ }, 
};

#define GW_CH_TABLE_SIZE  (sizeof(g_GwChannelTable) / sizeof(GatewayChannelMap_t))

// Gateway 當前頻率狀態 (預設為 0x05)
static SX1262_RfFreqSel_t g_GwCurrentTxEnum = SX1262_RF_FREQ_257MHZ; 
static SX1262_RfFreqSel_t g_GwCurrentRxEnum = SX1262_RF_FREQ_204MHZ;
static uint8_t g_GwCurrentChID = 0x05; 

// 應用頻率設定的輔助函式 (查表並更新全域變數)
bool Gateway_ApplyChannel(uint8_t chId) {
    for (int i = 0; i < GW_CH_TABLE_SIZE; i++) {
        if (g_GwChannelTable[i].channel_id == chId) {
            g_GwCurrentTxEnum = g_GwChannelTable[i].freq_tx;
            g_GwCurrentRxEnum = g_GwChannelTable[i].freq_rx;
            g_GwCurrentChID = chId; 
            UARTprintf("[GW] Config Updated to CH 0x%02X (TX:%d, RX:%d)\n", chId, g_GwCurrentTxEnum, g_GwCurrentRxEnum);
            return true;
        }
    }
    return false;
}

//*****************************************************************************
// Globals
//*****************************************************************************
uint32_t g_ui32IPAddress;
uint32_t g_ui32SysClock;
static volatile uint32_t g_ui32Tick = 0;
volatile uint32_t g_ui32SysTickCount = 0;

// LoRa Buffers
uint8_t g_LoraTxBuf[LORA_PKT_SIZE];
uint8_t g_LoraRxBuf[LORA_PKT_SIZE];

// UART1 Buffers (For Mode 1)
volatile uint8_t g_Uart1RxBuf[PAYLOAD_LEN];
volatile uint16_t g_Uart1RxIdx = 0;
volatile bool g_bUart1PacketReady = false;

// UDP Buffers (For Mode 0)
static uint8_t g_UdpTxPacket[UDP_TOTAL_LEN]; // 要送回 PC 的包
static char g_ipStr[16];
static char g_portStr[16];

//*****************************************************************************
// Helper: SystemClock for external libs
//*****************************************************************************
uint32_t SystemClock_get(void) { return g_ui32SysClock; }

#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line)
{
    while(1);
}
#endif

//*****************************************************************************
// Hardware Init Functions
//*****************************************************************************

// LED Control
void LED_Init_LoRa(void) {
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOM);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOM));
    GPIOPinTypeGPIOOutput(GPIO_PORTM_BASE, GPIO_PIN_6 | GPIO_PIN_7);
}
void LED_SetGreen(void) { GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_6); }
void LED_SetRed(void)   { GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_6 | GPIO_PIN_7, GPIO_PIN_7); }
void LED_AllOff(void)   { GPIOPinWrite(GPIO_PORTM_BASE, GPIO_PIN_6 | GPIO_PIN_7, 0); }

// LoRa Init
void LoRaGatewayInit(void) {

    SX1262_SelectRfFrequency(g_GwCurrentTxEnum);

    SX1262_Init(g_ui32SysClock);
    SX1262_SetTxPowerDbm(15);
    LED_SetGreen();
}

// UART1 Init (For Mode 1 Data Pipe)
// PB0 = U1RX, PB1 = U1TX
void Init_UART1(void) {
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_UART1));
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB));

    GPIOPinConfigure(GPIO_PB0_U1RX);
    GPIOPinConfigure(GPIO_PB1_U1TX);
    GPIOPinTypeUART(GPIO_PORTB_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART1_BASE, g_ui32SysClock, UART1_BAUDRATE,
                        (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

    UARTIntClear(UART1_BASE, UARTIntStatus(UART1_BASE, false));
    UARTIntEnable(UART1_BASE, UART_INT_RX | UART_INT_RT);
    IntEnable(INT_UART1);
}
// UART1 Interrupt Handler (Mode 1 Only)
void UART1IntHandler(void) {
    uint32_t ui32Status = UARTIntStatus(UART1_BASE, true);
    UARTIntClear(UART1_BASE, ui32Status);
    
    while(UARTCharsAvail(UART1_BASE)) {
        int32_t c = UARTCharGetNonBlocking(UART1_BASE);
        if (c != -1 && !g_bUart1PacketReady) {
            g_Uart1RxBuf[g_Uart1RxIdx++] = (uint8_t)(c & 0xFF);
            if (g_Uart1RxIdx >= PAYLOAD_LEN) {
                g_bUart1PacketReady = true;
                // Idx reset in main loop
            }
        }
    }
}

// Dummy UART0 Handler if needed (Standard UARTStdio uses its own)
// We rely on standard UARTStdio for UART0 logging.

//*****************************************************************************
// UDP Helper Functions
//*****************************************************************************
static void DisplayIPAddress(uint32_t ui32Addr) {
    char pcBuf[16];
    usprintf(pcBuf, "%d.%d.%d.%d",
             ui32Addr & 0xff, (ui32Addr >> 8) & 0xff,
             (ui32Addr >> 16) & 0xff, (ui32Addr >> 24) & 0xff);
    UARTprintf(pcBuf);
}

void lwIPHostTimerHandler(void) {
    uint32_t ui32NewIPAddress = lwIPLocalIPAddrGet();
    if(ui32NewIPAddress != g_ui32IPAddress) {
        if(ui32NewIPAddress == 0xffffffff) UARTprintf("Waiting for link.\n");
        else if(ui32NewIPAddress == 0) UARTprintf("Waiting for IP address.\n");
        else {
            UARTprintf("IP Address: ");
            DisplayIPAddress(ui32NewIPAddress);
            UARTprintf("\n");
        }
        g_ui32IPAddress = ui32NewIPAddress;
    }
}

void SysTickIntHandler(void) {
    lwIPTimer(SYSTICKMS);
    g_ui32Tick++;
    g_ui32SysTickCount++;
}

static void UARTPrintHex(const uint8_t *buf, uint32_t len) {
    uint32_t i;
    for(i = 0; i < len; i++) {
        UARTprintf("%02x", buf[i]);
        if(i != (len - 1)) UARTprintf(" ");
        if(((i + 1) % 16) == 0) UARTprintf("\n");
    }
    if((len % 16) != 0) UARTprintf("\n");
}

// 組建要回傳給 PC 的 UDP 封包
static void BuildAndSendUdpResponse(uint8_t *data250) {
    uint32_t ip = lwIPLocalIPAddrGet();
    usprintf(g_ipStr,   "%010u", ip);
    usprintf(g_portStr, "%010u", (uint32_t)PC_UDP_PORT);

    // Copy IP Header
    for(int i = 0; i < UDP_HEADER_IP_LEN; i++) g_UdpTxPacket[i] = (uint8_t)g_ipStr[i];
    // Copy Port Header
    for(int i = 0; i < UDP_HEADER_PORT_LEN; i++) g_UdpTxPacket[UDP_HEADER_IP_LEN + i] = (uint8_t)g_portStr[i];
    // Copy Data
    for(int i = 0; i < UDP_FRAME_LEN; i++) g_UdpTxPacket[UDP_HEADER_IP_LEN + UDP_HEADER_PORT_LEN + i] = data250[i];

    bool ok = UdpSend256(g_UdpTxPacket, UDP_TOTAL_LEN);
    UARTprintf("[UDP TX] Response Sent: %s\n", ok ? "OK" : "FAIL");
}

//*****************************************************************************
// MAIN
//*****************************************************************************
int main(void)
{
    uint32_t ui32User0, ui32User1;
    uint8_t pui8MACArray[8];

    // 1. System Clock
    SysCtlMOSCConfigSet(SYSCTL_MOSC_HIGHFREQ);
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                             SYSCTL_USE_PLL | SYSCTL_CFG_VCO_240), 120000000);
    MAP_FPUEnable();
    MAP_FPULazyStackingEnable();

    // 2. Hardware Init
    PinoutSet(true, false); // Standard LEDs (PN0/PN1) used by lwIP status

    // UART0 for LOGGING (Always)
    UARTStdioConfig(0, 115200, g_ui32SysClock);
    UARTprintf("\033[2J\033[H");
    UARTprintf("=== System Start ===\n");
    UARTprintf("Mode: %s\n", (SYSTEM_MODE == 0) ? "0 (UDP Bridge)" : "1 (UART1 Bridge)");
    UARTprintf("UART0: Logging Only\n");

    // Init SysTick
    MAP_SysTickPeriodSet(g_ui32SysClock / SYSTICKHZ);
    MAP_SysTickEnable();
    MAP_SysTickIntEnable();

    // Init MAC & lwIP
    MAP_FlashUserGet(&ui32User0, &ui32User1);
    if ((ui32User0 == 0xFFFFFFFF) || (ui32User1 == 0xFFFFFFFF)) {
        UARTprintf("No MAC, using default.\n");
        pui8MACArray[0]=0x02; pui8MACArray[1]=0x03; pui8MACArray[2]=0x04;
        pui8MACArray[3]=0x05; pui8MACArray[4]=0x06; pui8MACArray[5]=0x07;
    } else {
        pui8MACArray[0] = ((ui32User0 >>  0) & 0xff);
        pui8MACArray[1] = ((ui32User0 >>  8) & 0xff);
        pui8MACArray[2] = ((ui32User0 >> 16) & 0xff);
        pui8MACArray[3] = ((ui32User1 >>  0) & 0xff);
        pui8MACArray[4] = ((ui32User1 >>  8) & 0xff);
        pui8MACArray[5] = ((ui32User1 >> 16) & 0xff);
    }

    UARTprintf("Waiting for IP...\n");
    lwIPInit(g_ui32SysClock, pui8MACArray, 0, 0, 0, IPADDR_USE_DHCP);
    MAP_IntPrioritySet(INT_EMAC0, ETHERNET_INT_PRIORITY);
    MAP_IntPrioritySet(FAULT_SYSTICK, SYSTICK_INT_PRIORITY);

    while((lwIPLocalIPAddrGet() == 0) || (lwIPLocalIPAddrGet() == 0xffffffff)) {}
    (void)UdpTxInit();
    
    // 3. Init LoRa (ALWAYS ON NOW)
    UARTprintf("Initializing LoRa...\n");
    LED_Init_LoRa();
    LoRaGatewayInit();
    
    // Blink Check
    for(int i=0; i<4; i++) {
        if(i%2==0) LED_SetRed(); else LED_SetGreen();
        SysCtlDelay(g_ui32SysClock/10);
    }
    LED_SetGreen();
    UARTprintf("LoRa Ready.\n");

    // 4. Init UART1 (Only for Mode 1)
    if (SYSTEM_MODE == 1) {
        UARTprintf("Initializing UART1 for Data Pipe...\n");
        Init_UART1();
    }

    // 5. Main Loop
    while(1)
    {
        // ====================================================================
        // MODE 0: UDP <-> LoRa
        // ====================================================================
        if (SYSTEM_MODE == 0) 
        {
            uint8_t  udpRxBuf[PAYLOAD_LEN];
            uint16_t rxLen = 0;

            // 1. Check UDP Input
            UdpGetLastFrame250(udpRxBuf, &rxLen);

            if (rxLen == PAYLOAD_LEN) {
                UARTprintf("\n[UDP RX] Received 250 bytes -> Transmitting via LoRa...\n");
                LED_SetRed(); // TX Start

                // 2. Add Garbage Header & Transmit
                memcpy(g_LoraTxBuf, RF_GARBAGE, RF_OFFSET);
                memcpy(&g_LoraTxBuf[RF_OFFSET], udpRxBuf, PAYLOAD_LEN);
                SX1262_SetRfFrequency(g_GwCurrentTxEnum);
                SX1262_TransmitBlocking(g_LoraTxBuf, LORA_PKT_SIZE);
                LED_SetGreen(); // TX Done

                UARTprintf("[LoRa TX] Sent. Waiting for Reply (4s)...\n");

                // 3. Wait for LoRa Reply
                uint8_t loraRxLen = 0;
                SX1262_SetRfFrequency(g_GwCurrentRxEnum);
                bool hasData = SX1262_ReceiveBlocking(g_LoraRxBuf, LORA_PKT_SIZE, &loraRxLen, 4000);

                if (hasData && loraRxLen == LORA_PKT_SIZE) {
                    if (memcmp(g_LoraRxBuf, RF_GARBAGE, RF_OFFSET) == 0) {
                        UARTprintf("[LoRa RX] Valid Reply! Sending back via UDP...\n");
                        
                        // Blink Green
                        LED_AllOff(); SysCtlDelay(g_ui32SysClock/40);
                        LED_SetGreen(); SysCtlDelay(g_ui32SysClock/40);
                        LED_AllOff(); SysCtlDelay(g_ui32SysClock/40);
                        LED_SetGreen();

                        // 4. Send back via UDP
                        BuildAndSendUdpResponse(&g_LoraRxBuf[RF_OFFSET]);
                    } else {
                        UARTprintf("[LoRa RX] Invalid Garbage Header.\n");
                    }
                } else {
                    UARTprintf("[LoRa RX] Timeout or Wrong Length.\n");
                }
            }
        }
        
        // ====================================================================
        // MODE 1: UART1 <-> LoRa
        // ====================================================================
        else if (SYSTEM_MODE == 1) 
        {
            // 1. Check UART1 Input
            if (g_bUart1PacketReady) {
                UARTprintf("\n[UART1 RX] Received 250 bytes -> Transmitting via LoRa...\n");
                LED_SetRed();

                // 2. Add Garbage Header & Transmit
                memcpy(g_LoraTxBuf, RF_GARBAGE, RF_OFFSET);
                memcpy(&g_LoraTxBuf[RF_OFFSET], (void*)g_Uart1RxBuf, PAYLOAD_LEN);
                SX1262_SetRfFrequency(g_GwCurrentTxEnum);
                SX1262_TransmitBlocking(g_LoraTxBuf, LORA_PKT_SIZE);
                
                // Clear UART Flags
                g_bUart1PacketReady = false;
                g_Uart1RxIdx = 0;
                
                LED_SetGreen();
                UARTprintf("[LoRa TX] Sent. Waiting for Reply (4s)...\n");

                // 3. Wait for LoRa Reply
                uint8_t loraRxLen = 0;
                SX1262_SetRfFrequency(g_GwCurrentRxEnum);
                bool hasData = SX1262_ReceiveBlocking(g_LoraRxBuf, LORA_PKT_SIZE, &loraRxLen, 4000);

                if (hasData && loraRxLen == LORA_PKT_SIZE) {
                    if (memcmp(g_LoraRxBuf, RF_GARBAGE, RF_OFFSET) == 0) {
                        UARTprintf("[LoRa RX] Valid Reply! Sending back via UART1...\n");

                        // Blink Green
                        LED_AllOff(); SysCtlDelay(g_ui32SysClock/40);
                        LED_SetGreen(); SysCtlDelay(g_ui32SysClock/40);
                        LED_AllOff(); SysCtlDelay(g_ui32SysClock/40);
                        LED_SetGreen();

                        BuildAndSendUdpResponse(&g_LoraRxBuf[RF_OFFSET]);
                        // 4. Send back via UART1
                        for(int i=0; i<PAYLOAD_LEN; i++) {
                            UARTCharPut(UART1_BASE, g_LoraRxBuf[RF_OFFSET + i]);
                        }
                    } else {
                        UARTprintf("[LoRa RX] Invalid Garbage Header.\n");
                    }
                } else {
                    UARTprintf("[LoRa RX] Timeout or Wrong Length.\n");
                }
            }
        }
    }
}
