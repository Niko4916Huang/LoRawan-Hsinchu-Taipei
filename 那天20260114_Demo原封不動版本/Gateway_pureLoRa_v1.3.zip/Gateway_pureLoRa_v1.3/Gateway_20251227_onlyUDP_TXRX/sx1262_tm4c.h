#ifndef _SX1262_TM4C_H_
#define _SX1262_TM4C_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include <stdbool.h>

/* TivaWare headers */
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/ssi.h"
#include "driverlib/pin_map.h"

/* --------------------------------------------------------------------
 *  SX1262 ↔ TM4C1294 Pin Mapping
 *  若你的接線不同，就改下面這一區即可
 * ------------------------------------------------------------------*/

/* SPI : 使用 SSI1
 * SCK  : PB5 → SSI1CLK
 * MOSI : PE4 → SSI1XDAT0
 * MISO : PE5 → SSI1XDAT1
 * NSS  : PB4 → 手動 GPIO
 */
#define SX1262_SSI_PERIPH      SYSCTL_PERIPH_SSI1
#define SX1262_SSI_BASE        SSI1_BASE

#define SX1262_SCK_PERIPH      SYSCTL_PERIPH_GPIOB
#define SX1262_SCK_PORT        GPIO_PORTB_BASE
#define SX1262_SCK_PIN         GPIO_PIN_5

#define SX1262_NSS_PERIPH      SYSCTL_PERIPH_GPIOB
#define SX1262_NSS_PORT        GPIO_PORTB_BASE
#define SX1262_NSS_PIN         GPIO_PIN_4

#define SX1262_MOSI_PERIPH     SYSCTL_PERIPH_GPIOE
#define SX1262_MOSI_PORT       GPIO_PORTE_BASE
#define SX1262_MOSI_PIN        GPIO_PIN_4

#define SX1262_MISO_PERIPH     SYSCTL_PERIPH_GPIOE
#define SX1262_MISO_PORT       GPIO_PORTE_BASE
#define SX1262_MISO_PIN        GPIO_PIN_5

/* BUSY : 例如 PM0 */
#define SX1262_BUSY_PERIPH     SYSCTL_PERIPH_GPIOM
#define SX1262_BUSY_PORT       GPIO_PORTM_BASE
#define SX1262_BUSY_PIN        GPIO_PIN_0

/* NRESET : 例如 PM4 */
#define SX1262_NRESET_PERIPH   SYSCTL_PERIPH_GPIOM
#define SX1262_NRESET_PORT     GPIO_PORTM_BASE
#define SX1262_NRESET_PIN      GPIO_PIN_4

/* DIO1 / DIO2 : 例如 PN2 / PN1 （你原文 DIO1_PIN=PN2, DIO2_PIN=PN1） */
#define SX1262_DIO1_PERIPH     SYSCTL_PERIPH_GPION
#define SX1262_DIO1_PORT       GPIO_PORTN_BASE
#define SX1262_DIO1_PIN        GPIO_PIN_2

#define SX1262_DIO2_PERIPH     SYSCTL_PERIPH_GPION
#define SX1262_DIO2_PORT       GPIO_PORTN_BASE
#define SX1262_DIO2_PIN        GPIO_PIN_1

/* ANT_SW：例如 PL0，Low = TX, High = RX */
#define SX1262_ANTSW_PERIPH    SYSCTL_PERIPH_GPIOL
#define SX1262_ANTSW_PORT      GPIO_PORTL_BASE
#define SX1262_ANTSW_PIN       GPIO_PIN_0

/* --------------------------------------------------------------------
 *  小工具 Macro
 * ------------------------------------------------------------------*/
#define SX1262_NSS_LOW()   GPIOPinWrite(SX1262_NSS_PORT, SX1262_NSS_PIN, 0)
#define SX1262_NSS_HIGH()  GPIOPinWrite(SX1262_NSS_PORT, SX1262_NSS_PIN, SX1262_NSS_PIN)

#define SX1262_IS_BUSY()   (GPIOPinRead(SX1262_BUSY_PORT, SX1262_BUSY_PIN) ? true : false)

/* 若板子實際是 High=TX，就把 0 / SX1262_ANTSW_PIN 對調 */
#define SX1262_ANTSW_TX()  GPIOPinWrite(SX1262_ANTSW_PORT, SX1262_ANTSW_PIN, 0)
#define SX1262_ANTSW_RX()  GPIOPinWrite(SX1262_ANTSW_PORT, SX1262_ANTSW_PIN, SX1262_ANTSW_PIN)

/* --------------------------------------------------------------------
 * RF frequency selection (pre-calculated SetRfFrequency values)
 * ------------------------------------------------------------------*/
typedef enum
{
    SX1262_RF_FREQ_915MHZ = 0,
    SX1262_RF_FREQ_400MHZ,
    SX1262_RF_FREQ_204MHZ,
    SX1262_RF_FREQ_255MHZ,
	SX1262_RF_FREQ_257MHZ,
	SX1262_RF_FREQ_490MHZ,
	SX1262_RF_FREQ_833MHZ
} SX1262_RfFreqSel_t;

/* --------------------------------------------------------------------
 *  對外 API
 * ------------------------------------------------------------------*/

/* Select default RF freq used during SX1262_Init() */
void   SX1262_SelectRfFrequency(SX1262_RfFreqSel_t sel);

/* Immediately apply RF frequency to radio */
void   SX1262_SetRfFrequency(SX1262_RfFreqSel_t sel);

/* Init radio + IO */
void   SX1262_Init(uint32_t sysClockHz);

/* TX power setting */
void   SX1262_SetTxPowerDbm(int8_t dbm);

/* ---- TX/RX ----
 * 建議 TX blocking 回 bool，讓 main.c 可判斷 OK/FAIL
 * 若你的 sx1262_tm4c.c 目前是 void，請同步把 .c 改成回 bool
 */
bool   SX1262_TransmitBlocking(const uint8_t *data, uint8_t length);

bool   SX1262_ReceiveBlocking(uint8_t *data,
                              uint8_t  maxLen,
                              uint8_t *outLen,
                              uint32_t timeoutMs);

/* RSSI */
int16_t SX1262_ReadPacketRssi(void);

#ifdef __cplusplus
}
#endif

#endif /* _SX1262_TM4C_H_ */



/* 
typedef enum sx126x_gfsk_bw_e
{
    SX126X_GFSK_BW_4800   = 0x1F,
    SX126X_GFSK_BW_5800   = 0x17,
    SX126X_GFSK_BW_7300   = 0x0F,
    SX126X_GFSK_BW_9700   = 0x1E,
    SX126X_GFSK_BW_11700  = 0x16,
    SX126X_GFSK_BW_14600  = 0x0E,
    SX126X_GFSK_BW_19500  = 0x1D,
    SX126X_GFSK_BW_23400  = 0x15,
    SX126X_GFSK_BW_29300  = 0x0D,
    SX126X_GFSK_BW_39000  = 0x1C,
    SX126X_GFSK_BW_46900  = 0x14,
    SX126X_GFSK_BW_58600  = 0x0C,
    SX126X_GFSK_BW_78200  = 0x1B,
    SX126X_GFSK_BW_93800  = 0x13,
    SX126X_GFSK_BW_117300 = 0x0B,
    SX126X_GFSK_BW_156200 = 0x1A,
    SX126X_GFSK_BW_187200 = 0x12,
    SX126X_GFSK_BW_234300 = 0x0A,
    SX126X_GFSK_BW_312000 = 0x19,
    SX126X_GFSK_BW_373600 = 0x11,
    SX126X_GFSK_BW_467000 = 0x09,
} sx126x_gfsk_bw_t; */

/* typedef enum sx126x_ramp_time_e
{
    SX126X_RAMP_10_US   = 0x00,
    SX126X_RAMP_20_US   = 0x01,
    SX126X_RAMP_40_US   = 0x02,
    SX126X_RAMP_80_US   = 0x03,
    SX126X_RAMP_200_US  = 0x04,
    SX126X_RAMP_800_US  = 0x05,
    SX126X_RAMP_1700_US = 0x06,
    SX126X_RAMP_3400_US = 0x07,
} sx126x_ramp_time_t; */


/* typedef enum sx126x_gfsk_pulse_shape_e
{
    SX126X_GFSK_PULSE_SHAPE_OFF   = 0x00,
    SX126X_GFSK_PULSE_SHAPE_BT_03 = 0x08,
    SX126X_GFSK_PULSE_SHAPE_BT_05 = 0x09,
    SX126X_GFSK_PULSE_SHAPE_BT_07 = 0x0A,
    SX126X_GFSK_PULSE_SHAPE_BT_1  = 0x0B,
} sx126x_gfsk_pulse_shape_t; */
