#include "UDP.h"
#include "utils/uartstdio.h"
#include "lwip/udp.h"
#include "lwip/pbuf.h"
#include "lwip/ip_addr.h"
#include <string.h>

#define UDP_RX_LEN 250   //收資料長度

static struct udp_pcb *g_pcb = NULL;
static ip_addr_t g_dstIp;

static uint8_t  g_rxFrame[UDP_RX_LEN];   // 儲存最新一包 (已補0)
static uint16_t g_rxOrigLen = 0;

//================================================
// 提供 main.c 讀取
//================================================
void UdpGetLastFrame250(uint8_t *buf, uint16_t *rxLen)
{
    if(buf) memcpy(buf, g_rxFrame, UDP_RX_LEN);
    if(rxLen) *rxLen = g_rxOrigLen;
}

//================================================
// UDP RX Callback (收資料 → 補0到240存起來)
//================================================
static void UdpRecvCallback(void *arg, struct udp_pcb *pcb,
                            struct pbuf *p, const ip_addr_t *addr, u16_t port)
{
    (void)arg; (void)pcb; (void)addr; (void)port;

    if(!p) return;

    uint16_t len = p->tot_len;
    if(len > UDP_RX_LEN) len = UDP_RX_LEN;

    memset(g_rxFrame, 0x00, UDP_RX_LEN);
    pbuf_copy_partial(p, g_rxFrame, len, 0);

    g_rxOrigLen = p->tot_len;
    pbuf_free(p);
}

//================================================
// UDP INIT
//================================================
bool UdpTxInit(void)
{
    g_pcb = udp_new();
    if(!g_pcb) return false;

    if(udp_bind(g_pcb, IP_ADDR_ANY, PC_UDP_PORT) != ERR_OK)
        return false;

    IP4_ADDR(&g_dstIp, PC_IP_A, PC_IP_B, PC_IP_C, PC_IP_D);
    udp_recv(g_pcb, UdpRecvCallback, NULL);

    UARTprintf("[UDP Init] Ready RX/TX , PC=%d.%d.%d.%d:%d\n",
        PC_IP_A,PC_IP_B,PC_IP_C,PC_IP_D,PC_UDP_PORT);
    return true;
}

//================================================
// UDP 傳送
//================================================
bool UdpSend256(const uint8_t *data, uint16_t len)
{
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, len, PBUF_RAM);
    if(!p) return false;

    memcpy(p->payload, data, len);
    err_t e = udp_sendto(g_pcb, p, &g_dstIp, PC_UDP_PORT);

    pbuf_free(p);
    return (e==ERR_OK);
}
