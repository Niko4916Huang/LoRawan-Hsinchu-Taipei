#ifndef UDP_H_
#define UDP_H_

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

//===========================
// User Config (請修改這裡)
//===========================
// 你的電腦(PC) IP
#define PC_IP_A   192
#define PC_IP_B   168
#define PC_IP_C   1
#define PC_IP_D   100

// PC 用 Hercules 開的 UDP 監聽 Port
#define PC_UDP_PORT  5001

// UDP 初始化：建立 PCB、設定目的 IP
bool UdpTxInit(void);

// 送出 len bytes UDP payload
bool UdpSend256(const uint8_t *data, uint16_t len);

// 讀取最後一包 RX (240 Bytes, 不足補0)
void UdpGetLastFrame250(uint8_t *buf, uint16_t *rxLen);


#ifdef __cplusplus
}
#endif

#endif /* UDP_H_ */
