#ifndef AMP_UART_H
#define AMP_UART_H

#include <stdint.h>
#include <stdbool.h>

/* 每個 frame 的固定長度：200 bytes */
#define UARTLOG_FRAME_SIZE        200U

/* 最多儲存多少個 frame（可依 SRAM 調整） */
#define UARTLOG_MAX_FRAMES        1000U

/* 1D 陣列總長度 = 200 * frame 數 */
#define UARTLOG_TOTAL_BYTES       (UARTLOG_FRAME_SIZE * UARTLOG_MAX_FRAMES)

/* === UART1: PB0(U1RX), PB1(U1TX) === */
#define UARTLOG_UART_BASE         UART1_BASE
#define UARTLOG_UART_PERIPH       SYSCTL_PERIPH_UART1

#define UARTLOG_GPIO_PERIPH       SYSCTL_PERIPH_GPIOB
#define UARTLOG_GPIO_BASE         GPIO_PORTB_BASE
#define UARTLOG_GPIO_PINS         (GPIO_PIN_0 | GPIO_PIN_1)
#define UARTLOG_GPIO_PIN_RX       GPIO_PIN_0
#define UARTLOG_GPIO_PIN_TX       GPIO_PIN_1
#define UARTLOG_GPIO_PIN_CFG_RX   GPIO_PB0_U1RX
#define UARTLOG_GPIO_PIN_CFG_TX   GPIO_PB1_U1TX

/* 鮑率 */
#define UARTLOG_BAUD_RATE         38400U

/* Timer0A 用來每 100ms 送一次 command */
#define UARTLOG_TIMER_BASE        TIMER0_BASE
#define UARTLOG_TIMER_PERIPH      SYSCTL_PERIPH_TIMER0

// ----------------------------
// UART 指令陣列 (共 9 組，每組 18 bytes)
// ----------------------------
#define UARTLOG_CMD_LEN           17U
#define UARTLOG_CMD_COUNT         9U

/* header 長度：3 bytes（[0] 任意, [1] = 0xBE, [2] = 0x08）*/
#define UARTLOG_HEADER_LEN        6U

#ifdef __cplusplus
extern "C" {
#endif

/* 外部可見的 COMMAND 陣列 */
extern const uint8_t COMMAND[UARTLOG_CMD_COUNT][UARTLOG_CMD_LEN];

/* 初始化 UART1 + Timer0A（只送 command），並重設 logger 狀態 */
void        UartLog_Init(uint32_t sysClkHz);

/* 重設整體 logger */
void        UartLog_Reset(void);

/* 取得一維 buffer 指標（長度 UARTLOG_TOTAL_BYTES）*/
const uint8_t* UartLog_GetBuffer(void);

/* 取得目前已儲存 frame 數 */
uint32_t    UartLog_GetFrameCount(void);

/* 設定目前要送的 command index（0 ~ UARTLOG_CMD_COUNT-1） */
void        UartLog_SetCommandIndex(uint32_t index);

/* 立刻透過 UART1 送出一組 command[index]（blocking） */
void        UartLog_SendCommand(uint32_t index);

/* debug / 統計用全域變數 */
extern volatile uint32_t g_timer0a_cnt;
extern volatile uint32_t g_totalBytesRx;

#ifdef __cplusplus
}
#endif

#endif /* AMP_UART_H */
