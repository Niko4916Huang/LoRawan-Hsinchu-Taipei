#ifndef EXEEPROM_H_
#define EXEEPROM_H_

#include <stdint.h>
#include <stdbool.h>

// ============================================================================
// [EEPROM 規格參數] (Based on M95040 Datasheet [cite: 53-56])
// ============================================================================
// 記憶體大小: 4 Kbit = 512 Bytes
#define EEPROM_SIZE_BYTES   512

// 分頁大小: 16 Bytes [cite: 23]
// 重要：跨頁寫入時必須手動切斷，否則會捲回該頁開頭
#define EEPROM_PAGE_SIZE    16   

// ============================================================================
// [TM4C1294 硬體腳位配置] (Based on Image Table)
// ============================================================================
// 使用 SSI3 (Port Q)

#define EX_SSI_PERIPH       SYSCTL_PERIPH_SSI3
#define EX_SSI_BASE         SSI3_BASE

// GPIO Port 配置 (SSI3 腳位: PQ0, PQ1, PQ2, PQ3)
#define EX_GPIO_PERIPH      SYSCTL_PERIPH_GPIOQ
#define EX_GPIO_PORT        GPIO_PORTQ_BASE

// 腳位定義
#define EX_PIN_CLK          GPIO_PIN_0  // PQ0: EEPROM_SPI3_CLK (Pin 6)
#define EX_PIN_CS           GPIO_PIN_1  // PQ1: EEPROM_SPI3_SB  (Pin 1)
#define EX_PIN_TX           GPIO_PIN_2  // PQ2: EEPROM_SPI3_TX  (Pin 5) -> MOSI
#define EX_PIN_RX           GPIO_PIN_3  // PQ3: EEPROM_SPI3_RX  (Pin 2) -> MISO

// Pin Mux 配置 (TM4C1294 Vector)
#define EX_CFG_CLK          GPIO_PQ0_SSI3CLK
// #define EX_CFG_FSS       GPIO_PQ1_SSI3FSS // 我們用 GPIO 軟體控制 CS，所以不使用 FSS 硬體功能
#define EX_CFG_TX           GPIO_PQ2_SSI3XDAT0 // XDAT0 通常為 TX (MOSI)
#define EX_CFG_RX           GPIO_PQ3_SSI3XDAT1 // XDAT1 通常為 RX (MISO)

// --- Chip Select (CS/SS) ---
// 使用 PQ1 作為 GPIO Output
#define EX_CS_PERIPH        SYSCTL_PERIPH_GPIOQ
#define EX_CS_PORT          GPIO_PORTQ_BASE
#define EX_CS_PIN           GPIO_PIN_1

// --- Control Pins (Hold & Write Protect) ---
// HOLD: PF2 (Pin 7)
#define EX_HOLD_PERIPH      SYSCTL_PERIPH_GPIOF
#define EX_HOLD_PORT        GPIO_PORTF_BASE
#define EX_HOLD_PIN         GPIO_PIN_2

// WP: PP1 (Pin 3)
#define EX_WP_PERIPH        SYSCTL_PERIPH_GPIOP
#define EX_WP_PORT          GPIO_PORTP_BASE
#define EX_WP_PIN           GPIO_PIN_1

// 系統時鐘頻率 (與 main.c 一致)
extern uint32_t g_ui32SysClock; 

// ============================================================================
// [API 宣告]
// ============================================================================

// 初始化 SPI 硬體、CS、HOLD、WP 腳位
void EEPROM_Init(void);

// 讀取資料
// addr: 0 ~ 511
int EEPROM_Read(uint16_t addr, uint8_t *pBuf, uint16_t len);

// 寫入資料 (自動處理 Write Enable、Page Boundary 與 WIP Polling)
// addr: 0 ~ 511
int EEPROM_Write(uint16_t addr, uint8_t *pBuf, uint16_t len);

#endif /* EXEEPROM_H_ */
