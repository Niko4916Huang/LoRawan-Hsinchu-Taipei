#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "drivers/pinout.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/interrupt.h"
#include <stdbool.h> 
#include <string.h>  
#include <stdio.h>   

// API HEADER
#include "ledctrl.h"
#include "exeeprom.h" 
#include "aes128.h" 
#include "sx1262_tm4c.h" 
#include "AMP_uart.h" 

/*
            [提供本韌體可調整測試之MARCO定義區], 
            FACTORY_EEPROM_RESET_ENABLE 請用一次就好(第一次燒錄 = 1,之後 = 0)
            ENABLE_SYSTEM_LOG 如果使用 UART0模擬LoRa, 務必關閉
*/

#define FIRMWARE_VERSION "112" // Current Version 三位數, 112 代表 V1.1.2 (開發工程版本2)
#define FACTORY_EEPROM_RESET_ENABLE  0 // 開關設定：1 = 第一次使用and預設EEPROM燒錄測試值(Addison開發之Python自動化測試metadata對應) Log, 0 = 使用原EEPROM內讀取數據, 實際多版測試時, 請從外部燒寫EEPROM內值並關閉
#define ENABLE_SYSTEM_LOG   1 // 開關設定：1 = 開啟 Log, 0 = 關閉 Log, -1 = 用UART0 模擬 LoRa

#define SYSTEM_STATE_RESET  99 

// 封包定義架構 RF  =  [5] [230] [20] | [GAB_CHK] [**PAYLOAD**] [GAB_PAD]
#define ICD_PACKET_SIZE     255 
#define RF_OFFSET           5
#define REAL_LORA_SIZE      (ICD_PACKET_SIZE - RF_OFFSET) // 250

// 剩下 Padding，不處理
#define VALID_FRAME_LEN     230 

const uint8_t RF_GARBAGE_PATTERN[5] = {0x5A, 0xA5, 0x5A, 0xA5, 0x5A};

#define ICD_MSG_TYPE_TRIGGER 0xE0
#define ICD_MHDR_JOIN_REQ    0x00
#define ICD_MHDR_JOIN_ACC    0x20
#define ICD_MHDR_DATA_UP     0x40 
#define ICD_MHDR_DATA_DOWN   0x60 

#define DIR_UPLINK   0
#define DIR_DOWNLINK 1
#define JOIN_TIMEOUT_MS 10000 // 10s 視為 Timeout( 等待接收 OTAA Join-Accept 得時候)

uint8_t g_AmpData[9][200] = {0}; // AMP資料空間  

uint32_t g_ui32SysClock; 
static uint32_t g_lastAmpFrameCount = 0; 
static uint32_t g_lastScanFrameCount = 0; 
static uint8_t  g_currentScanIdx = 0;     

volatile uint32_t g_ui32SysTickCount = 0;
static bool wait_JoinAccept = false;
static uint32_t joinTimeoutStart = 0;
static bool is_RffreqSetResp = false;

#if (ENABLE_SYSTEM_LOG == 1)
    #define DBG_PRINT(...)  UARTprintf(__VA_ARGS__)
#else
    #define DBG_PRINT(...)  do { } while(0)
#endif

// =============================================================
//  系統變數跟架構定義
// =============================================================
static uint32_t SystemStatus = 0;

typedef struct {
    uint8_t  DevEUI[8];    
    uint8_t  JoinEUI[8];   
    uint8_t  AppKey[16];   
    uint8_t  NwkSKey[16];  
    uint8_t  AppSKey[16];  
    uint32_t DevAddr;      
    uint32_t FCntUp;       
    uint32_t FCntDown;     
    uint16_t DevNonce;     
    bool     IsJoined;     
} LoRa_Metadata; // LoRa 取用資料結構定義

LoRa_Metadata g_LoRaMetadata = {0}; 

// EEPROM Maps
#define EE_ADDR_DEVEUI    0x00  
#define EE_ADDR_JOINEUI   0x08  
#define EE_ADDR_APPKEY    0x10  
#define EE_ADDR_DEVNONCE  0x20  


void DebugOut( char *str, uint8_t *data, uint8_t data_len)  // Niko, debug out
{
	// ★★★ [Debug] Hex Dump (Optional) ★★★
	DBG_PRINT("[%s] Len:%d \nData: ", str, data_len);
	for(int i=0; i<data_len; i++) DBG_PRINT("%02X ", data[i]);
	DBG_PRINT("...\n");
    for(int j=0; j<data_len; j++) DBG_PRINT("%02X", data[j]);
	DBG_PRINT("...\n");
	
	return;

}


void MetaDataInit_EEPROM(void) // EEPROM 工廠資料預燒錄 / 開機後初始化讀取加載器 
{
    #if (FACTORY_EEPROM_RESET_ENABLE == 1) // 填入你想預燒錄的資料
        const uint8_t DEFAULT_DEVEUI[8] = { 0x70, 0xB3, 0xD5, 0x7E, 0xD0, 0x05, 0xA1, 0xB2 };
        const uint8_t DEFAULT_JOINEUI[8] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
        const uint8_t DEFAULT_APPKEY[16] = { 0xA2, 0x3C, 0x91, 0x55, 0x1B, 0xF8, 0xD0, 0x47, 0x89, 0x22, 0xE6, 0x04, 0x7D, 0x5A, 0x3F, 0x11 };
        DBG_PRINT("\n[FACTORY] !!! FACTORY RESET MODE ENABLED !!!\n");
        EEPROM_Write(EE_ADDR_DEVEUI,  (uint8_t*)DEFAULT_DEVEUI,  8);
        EEPROM_Write(EE_ADDR_JOINEUI, (uint8_t*)DEFAULT_JOINEUI, 8);
        EEPROM_Write(EE_ADDR_APPKEY,  (uint8_t*)DEFAULT_APPKEY,  16);
        uint8_t zero_nonce[2] = {0x00, 0x00};
        EEPROM_Write(EE_ADDR_DEVNONCE, zero_nonce, 2);
        DBG_PRINT("[FACTORY] Write Done.\n");
        SysCtlDelay(g_ui32SysClock / 3); 
    #endif

    int retry_count = 3;
    bool read_success = false;
    uint8_t buf_deveui[8], buf_joineui[8], buf_appkey[16], buf_nonce[2];

    while (retry_count > 0)
    {
        if (EEPROM_Read(EE_ADDR_DEVEUI,   buf_deveui,  8)  != 0) { retry_count--; continue; }
        if (EEPROM_Read(EE_ADDR_JOINEUI,  buf_joineui, 8)  != 0) { retry_count--; continue; }
        if (EEPROM_Read(EE_ADDR_APPKEY,   buf_appkey,  16) != 0) { retry_count--; continue; }
        if (EEPROM_Read(EE_ADDR_DEVNONCE, buf_nonce,   2)  != 0) { retry_count--; continue; }
        read_success = true;
        break;
    }

    if (!read_success)
    {
        DBG_PRINT("[INFO] EEPROM Read Error! System Rebooting...\n");
        while(UARTBusy(UART0_BASE)); 
        SysCtlReset(); 
        return;
    }
    else {
        DBG_PRINT("[INFO] DEV_EUI: ");
        for(int i=0; i<8; i++) DBG_PRINT("%02X ", buf_deveui[i]);
        DBG_PRINT("\n");
    }

    memcpy(g_LoRaMetadata.DevEUI,  buf_deveui,  8);
    memcpy(g_LoRaMetadata.JoinEUI, buf_joineui, 8);
    memcpy(g_LoRaMetadata.AppKey,  buf_appkey,  16);
    
    uint16_t currentNonce = buf_nonce[0] | (buf_nonce[1] << 8);
    if (currentNonce == 0xFFFF) currentNonce = 0;
    g_LoRaMetadata.DevNonce = currentNonce;

    uint16_t nonceToWrite = g_LoRaMetadata.DevNonce;
    buf_nonce[0] = (uint8_t)(nonceToWrite & 0xFF);
    buf_nonce[1] = (uint8_t)((nonceToWrite >> 8) & 0xFF);
    EEPROM_Write(EE_ADDR_DEVNONCE, buf_nonce, 2);
}

// =============================================================
//  頻率管理 (使用 Enum 版本)
// =============================================================

#define LORA_DTX_FREQ   SX1262_RF_FREQ_204MHZ // 預設TX 在 204
#define LORA_DRX_FREQ   SX1262_RF_FREQ_255MHZ // 預設RX 在 255 

// 結構修改：存放 Enum 而不是數字
typedef struct {
    uint8_t             channel_id; // 0x05, 0x06...
    SX1262_RfFreqSel_t  enum_tx;    // 上行頻率代號
    SX1262_RfFreqSel_t  enum_rx;    // 下行頻率代號
} LoRaChannelMap_t;

// 根據圖片建立對照表
static const LoRaChannelMap_t g_ChannelTable[] = {
    // Option |      TX (US) Enum     |      RX (DS) Enum
    {  0x05,    SX1262_RF_FREQ_204MHZ,  SX1262_RF_FREQ_257MHZ }, // Default
    {  0x06,    SX1262_RF_FREQ_204MHZ,  SX1262_RF_FREQ_257MHZ }, 
    {  0x07,    SX1262_RF_FREQ_204MHZ,  SX1262_RF_FREQ_833MHZ }, 
    {  0x08,    SX1262_RF_FREQ_204MHZ,  SX1262_RF_FREQ_833MHZ }, 
    {  0x09,    SX1262_RF_FREQ_490MHZ,  SX1262_RF_FREQ_490MHZ }, 
};

#define CHANNEL_TABLE_SIZE  (sizeof(g_ChannelTable) / sizeof(LoRaChannelMap_t))

//  全域變數改成 Enum 型態
static SX1262_RfFreqSel_t g_CurrentTxEnum = SX1262_RF_FREQ_204MHZ; // 預設值  第五頻道
static SX1262_RfFreqSel_t g_CurrentRxEnum = SX1262_RF_FREQ_257MHZ; // 預設值  第五頻道
static uint8_t g_CurrentChannelID = 0x05; // 預設值  第五頻道

static uint8_t g_CurrentAttenuator = 0x00;   // 預設值  (0 dB)

bool ApplyChannelConfig(uint8_t chId) {
    for (int i = 0; i < CHANNEL_TABLE_SIZE; i++) {
        if (g_ChannelTable[i].channel_id == chId) {
            g_CurrentTxEnum = g_ChannelTable[i].enum_tx;
            g_CurrentRxEnum = g_ChannelTable[i].enum_rx;
            g_CurrentChannelID = chId;
            // 這裡改成印出 Enum 的整數值 (index)
            DBG_PRINT("[Radio] Config Updated CH:0x%02X (Enum TX:%d, RX:%d)\n", 
                      chId, g_CurrentTxEnum, g_CurrentRxEnum);
            return true;
        }
    }
    return false;
}

void LoRa_Metadata_Init(void) { // LoRa Metadata 初始化器
    MetaDataInit_EEPROM(); 
    memset(g_LoRaMetadata.NwkSKey, 0, 16);
    memset(g_LoRaMetadata.AppSKey, 0, 16);
    g_LoRaMetadata.DevAddr = 0;
    g_LoRaMetadata.FCntUp = 0;   
    g_LoRaMetadata.FCntDown = 0; 
    g_LoRaMetadata.IsJoined = false; 
    DBG_PRINT("[LoRa] Metadata Initialized.\n");
}

void WriteLE32(uint8_t *buf, uint32_t val) { // 反轉為 Little Endian 用
    buf[0] = (uint8_t)(val & 0xFF);
    buf[1] = (uint8_t)((val >> 8) & 0xFF);
    buf[2] = (uint8_t)((val >> 16) & 0xFF);
    buf[3] = (uint8_t)((val >> 24) & 0xFF);
}

void MemCpy_Reverse(uint8_t *dest, uint8_t *src, uint16_t len) { // 反轉資料用
    for (uint16_t i = 0; i < len; i++) {
        dest[i] = src[len - 1 - i];
    }
}

void LoRa_CalculateMIC(uint8_t *msg, uint16_t msgLen, uint8_t *key, uint32_t devAddr, uint32_t fCnt, uint8_t dir, uint8_t *mic_out) { // LoRa MIC 計算器
    uint8_t B0[16];
    static uint8_t mic_calc_buf[300]; 
    memset(B0, 0, 16);
    B0[0] = 0x49;
    B0[5] = dir;
    WriteLE32(&B0[6], devAddr);
    WriteLE32(&B0[10], fCnt);
    B0[15] = (uint8_t)msgLen;
    memcpy(mic_calc_buf, B0, 16);
    memcpy(&mic_calc_buf[16], msg, msgLen);
    AES128_CMAC(key, mic_calc_buf, 16 + msgLen, mic_out);
}

void LoRa_EncryptDecryptPayload(uint8_t *buffer, uint16_t len, uint8_t *key, uint32_t devAddr, uint8_t dir, uint32_t fCnt) { // LoRa 加解密器 (XOR)
    uint8_t Ai[16]; 
    memset(Ai, 0, 16);
    Ai[0] = 0x01;
    Ai[5] = dir;
    WriteLE32(&Ai[6], devAddr);
    WriteLE32(&Ai[10], fCnt);
    Ai[15] = 0x01; 
    AES128_CTR_Encrypt(key, Ai, buffer, len, buffer);
}

void LoRa_DeriveSessionKeys(uint8_t *appKey, uint8_t *joinNonce, uint8_t *netID, uint16_t devNonce) { // LoRa OTAA 完成後算出金鑰用
    uint8_t input[16];
    memset(input, 0, 16);
    input[0] = 0x01;
    memcpy(&input[1], joinNonce, 3);
    memcpy(&input[4], netID, 3);
    input[7] = (uint8_t)(devNonce & 0xFF);
    input[8] = (uint8_t)((devNonce >> 8) & 0xFF);
    AES128_ECB_encrypt(appKey, input, g_LoRaMetadata.NwkSKey);
    input[0] = 0x02; 
    AES128_ECB_encrypt(appKey, input, g_LoRaMetadata.AppSKey);
    DBG_PRINT("[OTAA] OTAA Keys Derived.\n");
}

// UART0 模擬連接 Python Tester (如果 ENABLE_SYSTEM_LOG == -1)
volatile uint8_t Rx_Buffer[ICD_PACKET_SIZE];
volatile uint16_t Rx_Byte_Cnt = 0;
volatile uint8_t Rx_Flag = 0;

void UART0IntHandler(void) { // UART0 中斷器 
    #if (ENABLE_SYSTEM_LOG == -1)
    uint32_t ui32Status = UARTIntStatus(UART0_BASE, true);
    UARTIntClear(UART0_BASE, ui32Status);
    LEDCtrl_SetSolid(LED_RED);
    while(UARTCharsAvail(UART0_BASE)) {
        int32_t i32Char = UARTCharGetNonBlocking(UART0_BASE);
        if (i32Char != -1) {
            uint8_t c = (uint8_t)(i32Char & 0xFF);
            if (Rx_Byte_Cnt < ICD_PACKET_SIZE) {
                Rx_Buffer[Rx_Byte_Cnt++] = c;
            }
            if (Rx_Byte_Cnt >= ICD_PACKET_SIZE) {
                Rx_Flag = 1;      
                Rx_Byte_Cnt = 0;  
            }
        }
    }
    #endif
}


void UARTSendPacket(uint8_t *pBuffer, uint16_t len) { // UART0 給 Python Tester 發包器 (串口模擬)
    #if(ENABLE_SYSTEM_LOG == -1)
    for(uint16_t i = 0; i < len; i++) UARTCharPut(UART0_BASE, pBuffer[i]);
    #endif
}

// =================================================================
//  1. LoRa_Send_JoinRequest (使用 23 Bytes + 207 Padding 有效長度)
// =================================================================
void LoRa_Send_JoinRequest(void) {
    uint8_t txBuffer[ICD_PACKET_SIZE]; 
    uint8_t mic[4];
    
    memset(txBuffer, 0, ICD_PACKET_SIZE);
    memcpy(txBuffer, RF_GARBAGE_PATTERN, RF_OFFSET); 
    uint8_t *pFrame = &txBuffer[RF_OFFSET];

    pFrame[0] = ICD_MHDR_JOIN_REQ; 
    MemCpy_Reverse(&pFrame[1], g_LoRaMetadata.JoinEUI, 8); 
    MemCpy_Reverse(&pFrame[9], g_LoRaMetadata.DevEUI, 8);  
    pFrame[17] = (uint8_t)(g_LoRaMetadata.DevNonce & 0xFF);
    pFrame[18] = (uint8_t)((g_LoRaMetadata.DevNonce >> 8) & 0xFF);
    
    AES128_CMAC(g_LoRaMetadata.AppKey, pFrame, 19, mic);
    memcpy(&pFrame[19], mic, 4); 

    DBG_PRINT("[OTAA] Join-Request Generated (Nonce: %d)\n", g_LoRaMetadata.DevNonce);
    
    #if (ENABLE_SYSTEM_LOG == -1)
        UARTSendPacket(txBuffer, ICD_PACKET_SIZE); 
    #else
        SX1262_SetRfFrequency(g_CurrentTxEnum);
        SX1262_TransmitBlocking(txBuffer, ICD_PACKET_SIZE);
    #endif
}

// =================================================================
//  2. LoRa_Send_Data_Uplink (使用 230 Bytes 有效長度)
// =================================================================
void LoRa_Send_Data_Uplink(uint8_t *payload, uint8_t payloadLen) {
    uint8_t txBuffer[ICD_PACKET_SIZE]; 
    uint8_t mic[4];
    
    const uint8_t HEADER_LEN = 9;
    const uint8_t MIC_LEN = 4;
    const uint16_t ENCRYPT_LEN = VALID_FRAME_LEN - HEADER_LEN - MIC_LEN;

    memset(txBuffer, 0, ICD_PACKET_SIZE); 
    memcpy(txBuffer, RF_GARBAGE_PATTERN, RF_OFFSET);
    uint8_t *pFrame = &txBuffer[RF_OFFSET];

    pFrame[0] = 0x40; 
    pFrame[1] = (uint8_t)(g_LoRaMetadata.DevAddr & 0xFF);
    pFrame[2] = (uint8_t)((g_LoRaMetadata.DevAddr >> 8) & 0xFF);
    pFrame[3] = (uint8_t)((g_LoRaMetadata.DevAddr >> 16) & 0xFF);
    pFrame[4] = (uint8_t)((g_LoRaMetadata.DevAddr >> 24) & 0xFF);
    pFrame[5] = 0x00; 
    pFrame[6] = (uint8_t)(g_LoRaMetadata.FCntUp & 0xFF);
    pFrame[7] = (uint8_t)((g_LoRaMetadata.FCntUp >> 8) & 0xFF);
    pFrame[8] = 0x01; 
    
    if (payloadLen > ENCRYPT_LEN) payloadLen = ENCRYPT_LEN;
    if (payloadLen > 0) memcpy(&pFrame[9], payload, payloadLen);

    // 加密 227 bytes
    LoRa_EncryptDecryptPayload(&pFrame[9], ENCRYPT_LEN, g_LoRaMetadata.AppSKey, 
                               g_LoRaMetadata.DevAddr, DIR_UPLINK, g_LoRaMetadata.FCntUp);
    
    // 計算 MIC (範圍: 240 - 4 = 236 bytes)
    LoRa_CalculateMIC(pFrame, VALID_FRAME_LEN - MIC_LEN, g_LoRaMetadata.NwkSKey, 
                      g_LoRaMetadata.DevAddr, g_LoRaMetadata.FCntUp, DIR_UPLINK, mic);
    
    // 填入 MIC (放在第 236~239 byte)
    // 雖然 pFrame 是從 0 開始，但對應到 pFrame[236]
    memcpy(&pFrame[VALID_FRAME_LEN - MIC_LEN], mic, 4); 

    DBG_PRINT("[TX] Data Uplink (FCnt: %d)\n", g_LoRaMetadata.FCntUp);
    
    #if (ENABLE_SYSTEM_LOG == -1)
        UARTSendPacket(txBuffer, ICD_PACKET_SIZE); 
    #else
        SX1262_SetRfFrequency(g_CurrentTxEnum);
        SX1262_TransmitBlocking(txBuffer, ICD_PACKET_SIZE);
    #endif
    
    g_LoRaMetadata.FCntUp++;
}

void Init_SysTick(uint32_t ui32SysClock) { // 系統計數器初始化
    SysTickPeriodSet(ui32SysClock / 1000);
    SysTickIntEnable();
    SysTickEnable();
    IntMasterEnable();
}

void SysTick_Handler(void) { g_ui32SysTickCount++; } // 系統計數器

void ConfigureSystemUART(void) { // UART0 初始化器 (如果有啟用 UART0 模擬與電腦 Python Tester對連接會開中斷)

    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    MAP_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0); 
    MAP_GPIOPinConfigure(GPIO_PA0_U0RX);
    MAP_GPIOPinConfigure(GPIO_PA1_U0TX);
    MAP_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTStdioConfig(0, 115200, g_ui32SysClock);

    #if(ENABLE_SYSTEM_LOG == -1)
    UARTIntRegister(UART0_BASE, UART0IntHandler); 
    UARTIntEnable(UART0_BASE, UART_INT_RX | UART_INT_RT); 
    IntEnable(INT_UART0); 
    #endif
}

void SystemInit() { // 系統初始化器
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_240), 120000000); 
    ConfigureSystemUART(); 
    DBG_PRINT("System On, V.%s\n", FIRMWARE_VERSION);
    DBG_PRINT(" System Clock: %d MHz\n", g_ui32SysClock / 1000000);
}

void LoRaSystemInit(void) { // LoRa初始化器
    DBG_PRINT("[LoRa] SX1262 Hardware Init...\n");

    // 1. [新增] 預選頻率
    // 這一行必須在 Init 之前，讓 Driver 知道基礎頻段
    SX1262_SelectRfFrequency(LORA_DTX_FREQ);

    // 2. 硬體初始化 (SPI, GPIO, Reset...)
    SX1262_Init(g_ui32SysClock);

    // 3. 設定發射功率
    SX1262_SetTxPowerDbm(15);    // 0 dbm  
    
    //此時晶片處於 Standby 模式，等待你在 main loop 下達 Tx 或 Rx 指令
    DBG_PRINT("[LoRa] SX1262 Init Done (Freq selected, Power set).\n");
}

void AMPInit(void) { // AMP 初始化器
    UartLog_Init(g_ui32SysClock);
    DBG_PRINT("[AMP] UART1 Initialized.\n");
}

void AMP_Scanner_Process(void) { // AMP 從輪詢後面每100ms抓回來Data 塞入 200 Bytes Buffer 器
    uint32_t currentTotal = UartLog_GetFrameCount();
    if (currentTotal > g_lastScanFrameCount) {
        const uint8_t* pBigBuffer = UartLog_GetBuffer();
        uint32_t frameIndex = (currentTotal - 1) % UARTLOG_MAX_FRAMES;
        const uint8_t* pLatestFrame = &pBigBuffer[frameIndex * UARTLOG_FRAME_SIZE];
        memcpy(&g_AmpData[g_currentScanIdx][0], pLatestFrame, 200);
        g_lastScanFrameCount = currentTotal;
        g_currentScanIdx++;
        if (g_currentScanIdx >= 9) g_currentScanIdx = 0; 
        UartLog_SetCommandIndex(g_currentScanIdx);
    }
}

void LoRaOTAADataClear(void) { // 每次 OTAA 清掉 Cache 器
    g_LoRaMetadata.DevAddr = 0; g_LoRaMetadata.IsJoined = false;
    g_LoRaMetadata.FCntUp = 0; g_LoRaMetadata.FCntDown = 0;
}

void DevNoncePlusOne(void) { // DevNonce +1 存起來器
    g_LoRaMetadata.DevNonce++;   
    uint8_t buf_nonce[2];
    buf_nonce[0] = (uint8_t)(g_LoRaMetadata.DevNonce & 0xFF);
    buf_nonce[1] = (uint8_t)((g_LoRaMetadata.DevNonce >> 8) & 0xFF);
    if (EEPROM_Write(EE_ADDR_DEVNONCE, buf_nonce, 2) != 0) {
        DBG_PRINT("[INFO] Failed to save DevNonce!\n");
        SysCtlReset();
    } else {
        DBG_PRINT("[OTAA] DevNonce Updated: %d\n", g_LoRaMetadata.DevNonce);
    }
}

/*================== Main Process ==================*/

int main(void)
{
    uint8_t local_pkt[ICD_PACKET_SIZE] = {0}; 
    SystemStatus = 0;
    
    while(1){ 
        if (SystemStatus >= 1) { // LED 更新狀態機
            LEDCtrl_Update(g_ui32SysTickCount); 
            AMP_Scanner_Process();
        }

        if (wait_JoinAccept) { // 如有 Join Accept 看有沒有在 Timeout內收到器
            if ((g_ui32SysTickCount - joinTimeoutStart) > JOIN_TIMEOUT_MS) {
                wait_JoinAccept = false;
                LEDCtrl_FlashAndRestore(LED_GREEN); 
                DBG_PRINT("[OTAA] Join Timeout.\n");
            }
        }
        
        switch (SystemStatus) {

            case 0: // 一切必要系統初始化加載 
                SystemInit(); 
                Init_SysTick(g_ui32SysClock); 
                LEDCtrl_Init(); 
                LEDCtrl_FlashAndStay(LED_RED); // ------ 開機紅燈
                EEPROM_Init(); 
                AMPInit(); 
                LoRa_Metadata_Init(); 
                DBG_PRINT("[INIT] Done.\n"); 
                SystemStatus = 1; 
                break;

            case 1:   // 初始化 LoRa SX1262 RF (RF沒有 Att 跟 PLL 了)
                LoRaSystemInit(); 
                LEDCtrl_FlashAndStay(LED_GREEN); // ------ 到了 LoRa 加載結束綠燈


                SystemStatus = 2; 
                break;
            
            // ============================================================
            // Case 2: 核心處理 (RX, OTAA, Data)
            // ============================================================
            case 2: 
                uint8_t rx_len = 0;
                // LoRa SX1262 接收窗口, 1500ms Timeout
                SX1262_SetRfFrequency(g_CurrentRxEnum);
                bool pktReceived = SX1262_ReceiveBlocking(Rx_Buffer, ICD_PACKET_SIZE, &rx_len, 1500);

                if (pktReceived && rx_len > 0) { Rx_Flag = 1; }

                if (Rx_Flag == 1) {  
                    Rx_Flag = 0;
                    memcpy(local_pkt, (void*)Rx_Buffer, ICD_PACKET_SIZE); 

                    if (memcmp(local_pkt, RF_GARBAGE_PATTERN, RF_OFFSET) != 0) {
                        DBG_PRINT("[RX Err] Bad Header: %02X %02X...\n", local_pkt[0], local_pkt[1]);
                    }
                    else {
                    	/*
                        // ★★★ [Debug] Hex Dump (Optional) ★★★
                        DBG_PRINT("[RX OK] Len:%d Data: ", rx_len);
                        for(int i=0; i<255; i++) DBG_PRINT("%02X ", local_pkt[i]);
                        DBG_PRINT("...\n");
                    */    
                        DebugOut("RX OK", local_pkt, rx_len);		// niko, debug out

                        uint8_t *pFrame = &local_pkt[RF_OFFSET]; 
                        uint8_t header = pFrame[0];

                        // --- 1. Trigger (0xE0) ---
                        if (header == ICD_MSG_TYPE_TRIGGER) { 
                            if (!wait_JoinAccept) {
                                bool devEUI_Match = true;
                                for(int i=0; i<8; i++) {
                                    if (pFrame[1 + i] != g_LoRaMetadata.DevEUI[7 - i]) {
                                        devEUI_Match = false; break;
                                    }
                                }
                                if (devEUI_Match) {
                                    DBG_PRINT("[OTAA] Trigger Matched.\n");
                                    LEDCtrl_FlashAndRestore(LED_RED); // ------ OTAA 被觸發上行亮紅燈
                                    memset(g_LoRaMetadata.NwkSKey, 0, 16);
                                    memset(g_LoRaMetadata.AppSKey, 0, 16);
                                    LoRaOTAADataClear();
                                    DevNoncePlusOne();
                                    
                                    SysCtlDelay(g_ui32SysClock / 3 / 2); // 500ms Delay 卡死 ( 保護 EEPROM 都有存好 )
                                    
                                    LoRa_Send_JoinRequest();
                                    wait_JoinAccept = true;
                                    joinTimeoutStart = g_ui32SysTickCount;
                                }
                            }
                        }
                        // --- 2. Join-Accept (0x20) ---
                        else if (header == ICD_MHDR_JOIN_ACC) {
                            if (wait_JoinAccept) {
                                wait_JoinAccept = false; 
                                uint8_t enc_payload[32], dec_payload[32]; 
                                memset(enc_payload, 0, 32);
                                memset(dec_payload, 0, 32);

                                // ★★★ 關鍵修改：根據長度解密 ★★★
                                // if (loraPayloadLen == 33) {
                                    // 解密 2 個 Block (32 bytes)
                                    memcpy(enc_payload, &pFrame[1], 32);
                                    AES128_ECB_encrypt(g_LoRaMetadata.AppKey, &enc_payload[0], &dec_payload[0]);   // 1-16
                                    AES128_ECB_encrypt(g_LoRaMetadata.AppKey, &enc_payload[16], &dec_payload[16]); // 17-32
                                    DBG_PRINT("[OTAA] 33-Byte JA (With CFList)\n");
                                    DebugOut("dec_payload", dec_payload, 32);		// niko, debug out
                                // } 
                                // else {
                                //     // 標準 17 bytes (16 bytes payload)
                                //     memcpy(enc_payload, &pFrame[1], 16);
                                //     AES128_ECB_encrypt(g_LoRaMetadata.AppKey, enc_payload, dec_payload);
                                //     DBG_PRINT("[OTAA] 17-Byte JA (Std)\n");
                                // }

                                uint8_t mic_check_buf[64], calc_mic[4];
                                uint8_t cmac_len = 0;
                                uint8_t *pMicFromPkt = NULL;

                                mic_check_buf[0] = pFrame[0]; // MHDR

                                // ★★★ 關鍵修改：計算 MIC 的範圍 ★★★
                                // if (loraPayloadLen == 33) {
                                    // 33 bytes: MHDR(1) + Payload(28) + MIC(4)
                                    // CMAC input: MHDR + DecPayload[0..27]
                                    memcpy(&mic_check_buf[1], dec_payload, 28);
                                    cmac_len = 29;
                                    pMicFromPkt = &dec_payload[28];
                                    
                                // } else {
                                //     // 17 bytes: MHDR(1) + Payload(12) + MIC(4)
                                //     // CMAC input: MHDR + DecPayload[0..11]
                                //     memcpy(&mic_check_buf[1], dec_payload, 12);
                                //     cmac_len = 13;
                                //     pMicFromPkt = &dec_payload[12];
                                // }

                                AES128_CMAC(g_LoRaMetadata.AppKey, mic_check_buf, cmac_len, calc_mic);
                                
                                DebugOut("AppKey", g_LoRaMetadata.AppKey, 16);		// niko, debug out
                                

                                if (memcmp(calc_mic, pMicFromPkt, 4) == 0) {
                                    DBG_PRINT("[OTAA] MIC OK. Joined!\n");
                                    uint8_t *pAppNonce = &dec_payload[0];
                                    uint8_t *pNetID = &dec_payload[3];
                                    uint32_t newDevAddr = dec_payload[6] | (dec_payload[7]<<8) | (dec_payload[8]<<16) | (dec_payload[9]<<24);
                                    LoRa_DeriveSessionKeys(g_LoRaMetadata.AppKey, pAppNonce, pNetID, g_LoRaMetadata.DevNonce);
                                    g_LoRaMetadata.DevAddr = newDevAddr;
                                    g_LoRaMetadata.IsJoined = true;
                                    g_LoRaMetadata.FCntUp = 0;
                                    g_LoRaMetadata.FCntDown = 0;
                                    LEDCtrl_FlashAndRestore(LED_GREEN); 
                                    DBG_PRINT("[OTAA] received DevAddr: %08X\n", g_LoRaMetadata.DevAddr);
                                    DebugOut("NwkSKey", g_LoRaMetadata.NwkSKey, 16);		// niko, debug out
                                    DebugOut("AppSKey", g_LoRaMetadata.AppSKey, 16);		// niko, debug out
                                } else {
                                    DBG_PRINT("[OTAA] MIC Mismatch.\n"); 
                                }
                            }
                            // if (wait_JoinAccept) {
                            //     wait_JoinAccept = false; 
                            //     uint8_t enc_payload[16], dec_payload[16]; 
                            //     memcpy(enc_payload, &pFrame[1], 16);
                            //     AES128_ECB_encrypt(g_LoRaMetadata.AppKey, enc_payload, dec_payload);

                            //     uint8_t mic_check_buf[13], calc_mic[4];
                            //     mic_check_buf[0] = pFrame[0]; 
                            //     memcpy(&mic_check_buf[1], dec_payload, 12); 
                            //     AES128_CMAC(g_LoRaMetadata.AppKey, mic_check_buf, 13, calc_mic);

                            //     if (memcmp(calc_mic, &dec_payload[12], 4) == 0) {
                            //         DBG_PRINT("[OTAA] Join-Accept Valid.\n");
                            //         uint8_t *pAppNonce = &dec_payload[0];
                            //         uint8_t *pNetID = &dec_payload[3];
                            //         uint32_t newDevAddr = dec_payload[6] | (dec_payload[7]<<8) | (dec_payload[8]<<16) | (dec_payload[9]<<24);
                            //         LoRa_DeriveSessionKeys(g_LoRaMetadata.AppKey, pAppNonce, pNetID, g_LoRaMetadata.DevNonce);
                            //         g_LoRaMetadata.DevAddr = newDevAddr;
                            //         g_LoRaMetadata.IsJoined = true;
                            //         g_LoRaMetadata.FCntUp = 0;
                            //         g_LoRaMetadata.FCntDown = 0;
                            //         LEDCtrl_FlashAndRestore(LED_GREEN);  // ------ Join Accept 成功收到然後處理好 !!! 亮綠燈
                            //     } else {
                            //         DBG_PRINT("[OTAA] MIC Mismatch.\n"); // 這包 JAC 沒料(可能收到別人的或)回到靜默等下次OTAA Trigger
                            //     }
                            // }
                        }
                        // --- 3. Downlink Data (0x60) ---
                        else if (header == ICD_MHDR_DATA_DOWN) {
                            // 必須已入網且不在等待 JAC
                            if (g_LoRaMetadata.IsJoined && !wait_JoinAccept) {
                                uint32_t rxDevAddr = pFrame[1] | (pFrame[2]<<8) | (pFrame[3]<<16) | (pFrame[4]<<24);
                                uint8_t rxFPort = pFrame[8];
                                
                                DBG_PRINT("[Downlink] FPort must = 10, RX FPort: %d.\n", rxFPort);

                                // DevAddr 與 Port 檢查 (看是不是給自己的東西)
                                if ((rxDevAddr == g_LoRaMetadata.DevAddr) && (rxFPort == 10)) { // 只吃 APP 封包, FPort = 10 !!! 
                                    uint16_t rxFCnt16 = pFrame[6] | (pFrame[7]<<8);
                                    uint32_t temp_FCntDown = (g_LoRaMetadata.FCntDown & 0xFFFF0000) | rxFCnt16;
                                    
                                    // FCnt 回捲處理 (roll回來)
                                    if (rxFCnt16 < (g_LoRaMetadata.FCntDown & 0xFFFF) && 
                                        ((g_LoRaMetadata.FCntDown & 0xFFFF) - rxFCnt16) > 32768) {
                                        temp_FCntDown += 0x10000;
                                    }

                                    // Valid Frame - 4 (MIC) 這邊再算封包是不是合法 MIC
                                    uint16_t mic_calc_len = VALID_FRAME_LEN - 4 ; 
                                    uint16_t mic_index = VALID_FRAME_LEN - 4;    

                                    uint8_t calc_mic[4];
                                    
                                    // 呼叫計算函式
                                    LoRa_CalculateMIC(
                                        pFrame,           // 資料指標 (從 Header 開始)
                                        mic_calc_len,     // 長度 236
                                        g_LoRaMetadata.NwkSKey, 
                                        rxDevAddr, 
                                        temp_FCntDown, 
                                        DIR_DOWNLINK,     // 必須是 1
                                        calc_mic
                                    );
                                    
                                    
                                    if (memcmp(calc_mic, &pFrame[mic_index], 4) == 0) { // 如果算出來 跟 封包給的都一樣 (合法的good) 
                                        g_LoRaMetadata.FCntDown = temp_FCntDown;                                     
                                        uint8_t *pEncPayload = &pFrame[9];
                                        
                                        // 解密實際被加密的 FRMPayload 217 Bytes, 這裡只吃 FPort = 10 的 App 封包, 用 AppSKey 來解密
                                        LoRa_EncryptDecryptPayload(pEncPayload, VALID_FRAME_LEN - 9 - 4, g_LoRaMetadata.AppSKey, rxDevAddr, DIR_DOWNLINK, temp_FCntDown);
                                        
                                        uint8_t *pPlain = pEncPayload; 
                                        uint8_t opCode1 = pPlain[0];
                                        uint8_t opCode2 = pPlain[1];
                                        uint8_t *pDataContent = &pPlain[3];

                                        DBG_PRINT("[Data] Op: %02X %02X\n", opCode1, opCode2);

                                        // ==========================================
                                        // 指令處理邏輯 ( 配合 ICD 定義可用指令表 )
                                        // ==========================================
                                        
                                        // A. Health Check (10 11)
                                    if (opCode1 == 0x10 && opCode2 == 0x11) { 
                                        uint8_t resp[64], idx = 0;
                                        
                                        // Header: OpCode(10 12) + Len(TBD)
                                        resp[idx++] = 0x10; 
                                        resp[idx++] = 0x12; 
                                        resp[idx++] = 0;    // Len 
                                        resp[idx++] = g_CurrentChannelID;  // 回報當前 Channel (例如 0x05)
                                        resp[idx++] = g_CurrentAttenuator; // 回報當前 Attenuator (例如 0x00)
                                        
                                        // Version String (依照 ICD, 純 ASCII, 無小數點)
                                        char ascii_buf[32];
                                        sprintf(ascii_buf, "%s", FIRMWARE_VERSION);
                                        uint8_t ascii_len = strlen(ascii_buf);
                                        memcpy(&resp[idx], ascii_buf, ascii_len);
                                        idx += ascii_len;                   
                                        
                                        // 填回 Length (總長度 - OpCode 2 bytes - Len 1 byte)
                                        resp[2] = idx - 3; 
                                        
                                        // 發送回應
                                        LoRa_Send_Data_Uplink(resp, idx);
                                        
                                        DBG_PRINT("[Health] Reported CH:0x%02X, Att:%02X, Ver:%s\n", 
                                                  g_CurrentChannelID, g_CurrentAttenuator, ascii_buf);
                                    }
                                        // B. LED Control (20 01)
                                        else if (opCode1 == 0x20 && opCode2 == 0x01) { 
                                            if (pDataContent[0] == 1) LEDCtrl_SetSolid(LED_RED);
                                            else if (pDataContent[0] == 2) LEDCtrl_SetSolid(LED_GREEN);
                                            // Optional: 回覆 ACK? 目前 Python 端沒要求 這包不用 ACK 回去
                                        }
                                        // C. AMP Request (40 01)
                                        else if (opCode1 == 0x40 && opCode2 == 0x01) { 
                                            uint8_t action = pDataContent[0];
                                            if (action >= 1 && action <= 9) {
                                                uint8_t arrayIdx = action - 1;
                                                uint8_t amp_resp[205]; 
                                                amp_resp[0] = 0x40; amp_resp[1] = 0x02; amp_resp[2] = 200;  
                                                memcpy(&amp_resp[3], &g_AmpData[arrayIdx][0], 200);
                                                LoRa_Send_Data_Uplink(amp_resp, 203); // 內容物 0x40 0x02 + 最大 200 Bytes (沒有地方補 0x00) 後面照常補 0x00 
                                                DBG_PRINT("[AMP] Cache Hit %d.\n", arrayIdx);
                                                 DebugOut("AmpData", amp_resp, 203);		// niko, debug out
                                            }
                                        }
                                       else if (opCode1 == 0x30 && opCode2 == 0x01) { 
                                        // 根據 ICD 定義：Payload Byte 0 = Channel, Byte 1 = Attenuator
                                        uint8_t req_ch = pDataContent[0];
                                        uint8_t req_att = pDataContent[1];
                                        
                                        // 1. 嘗試應用新的頻率設定 (更新 g_CurrentTxEnum / RxEnum)
                                        // 這會立即改變全域變數，下一次 TX/RX 就會生效
                                        if (ApplyChannelConfig(req_ch)) {
                                            
                                            // TODO: 如果有控制衰減器的硬體函式，請在這裡呼叫
                                            // Set_Attenuator_Loss(req_att); 
                                            
                                            // 2. 準備回覆封包 (OpCode 30 02 - Freq_Config_Resp)
                                            // 結構: [Op1][Op2][Len][Channel][Attenuator]
                                            uint8_t resp_buf[8]; // 足夠放 Header + Payload
                                            uint8_t ridx = 0;
                                            g_CurrentAttenuator = req_att;
                                            resp_buf[ridx++] = 0x30; // OpCode 1
                                            resp_buf[ridx++] = 0x02; // OpCode 2
                                            resp_buf[ridx++] = 0x02; // Payload Len (CH + Att)
                                            resp_buf[ridx++] = g_CurrentChannelID; // Payload: 目前的 Channel
                                            resp_buf[ridx++] = g_CurrentAttenuator;// Payload: 目前的 Attenuator
                                            
                                            // 3. 發送回覆
                                            // 注意：因為上面已經呼叫 ApplyChannelConfig 更新了 g_CurrentTxEnum，
                                            // LoRa_Send_Data_Uplink 內部會呼叫 SX1262_SetRfFrequency(g_CurrentTxEnum)，
                                            // 所以這包 Response 會用「新頻率」發送出去。
                                            LoRa_Send_Data_Uplink(resp_buf, ridx);
                                            
                                            DBG_PRINT("[Config] Success. Switched to CH:0x%02X (Att:%d)\n", req_ch);
                                        } 
                                        else {
                                            // Channel ID 查表失敗
                                            DBG_PRINT("[Config] Failed. Invalid Channel ID: 0x%02X\n", req_ch);
                                        }
                                    }
                                        // E. Reboot (A0 A0)
                                        else if (opCode1 == 0xA0 && opCode2 == 0xA0) { 
                                            SystemStatus = SYSTEM_STATE_RESET; // 系統立即重開機
                                        }
                                        else {
                                            DBG_PRINT("[Data] Unknown OpCode.\n");
                                        }

                                    } else {
                                        DBG_PRINT("[Err] Data MIC Fail.\n");
                                    }
                                } else {
                                    DBG_PRINT("[Data] DevAddr Mismatch. Exp: %08X, Got: %08X\n", g_LoRaMetadata.DevAddr, rxDevAddr);
                                }
                            } else {
                                DBG_PRINT("[Data] Ignore. Not Joined or Waiting JA.\n");
                            }
                        }
                    }
                }
                break;

            case SYSTEM_STATE_RESET: 
                SysCtlReset(); 
                while(1); 
                break;

            default:
                SystemStatus = SYSTEM_STATE_RESET;
                break;
        }
    }
    SysCtlReset();
}
