/*
 * ledctrl.c
 */

#include "ledctrl.h"
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"

// --- 硬體定義 (參照 Transponder Pin Define csv) ---
#define LED_PORT_BASE      GPIO_PORTM_BASE
#define LED_PERIPH         SYSCTL_PERIPH_GPIOM
#define PIN_RED            GPIO_PIN_6   // PM6
#define PIN_GREEN          GPIO_PIN_7   // PM7

// --- 參數設定 ---
#define FLASH_DURATION_MS  200          // 閃爍持續時間 200ms

// --- 內部變數 (狀態機) ---
static LED_Color_t g_StableColor = LED_OFF; // 穩定狀態的顏色 (背景色)
static LED_Color_t g_FlashColor  = LED_OFF; // 閃爍時顯示的顏色
static bool        g_IsFlashing  = false;   // 是否正在閃爍中
static uint32_t    g_FlashStartTime = 0;    // 閃爍開始的時間戳記

// --- 內部函式：硬體寫入 (Active Low) ---
// 0 = 亮, 1 = 滅
static void _HW_Write(LED_Color_t color)
{
    uint8_t pinValue = 0;

    // 預設兩燈都滅 (設為 1)
    // 這裡先準備一個 Mask，稍後用來寫入
    // Bit 6 = Red, Bit 7 = Green
    uint8_t redBit   = PIN_RED;   // Default OFF (High)
    uint8_t greenBit = PIN_GREEN; // Default OFF (High)

    switch (color)
    {
        case LED_RED:
            redBit = 0;         // Red ON (Low)
            break;
        case LED_GREEN:
            greenBit = 0;       // Green ON (Low)
            break;
        case LED_YELLOW:        // Red + Green
            redBit = 0;
            greenBit = 0;
            break;
        case LED_OFF:
        default:
            // 保持全滅 (High)
            break;
    }

    // 同時寫入 PM6 和 PM7，避免切換時產生殘影
    GPIOPinWrite(LED_PORT_BASE, PIN_RED | PIN_GREEN, redBit | greenBit);
}

// --- API 實作 ---

void LEDCtrl_Init(void)
{
    // 1. 啟用 Port M
    SysCtlPeripheralEnable(LED_PERIPH);
    while(!SysCtlPeripheralReady(LED_PERIPH));

    // 2. 設定 PM6, PM7 為輸出
    GPIOPinTypeGPIOOutput(LED_PORT_BASE, PIN_RED | PIN_GREEN);

    // 3. 預設全滅
    LEDCtrl_SetSolid(LED_OFF);
}

void LEDCtrl_SetSolid(LED_Color_t color)
{
    g_IsFlashing = false;      // 強制停止閃爍
    g_StableColor = color;     // 更新穩定狀態顏色
    _HW_Write(g_StableColor);  // 立即更新硬體
}

void LEDCtrl_FlashAndRestore(LED_Color_t flashColor)
{
    // Type 1: 記錄閃爍色，開啟閃爍旗標
    // 重點：不改變 g_StableColor，所以時間到會變回原本的樣子
    g_FlashColor = flashColor;
    g_IsFlashing = true;
    g_FlashStartTime = 0; // 標記為 0，讓 Update 函式去抓當下的時間
}

void LEDCtrl_FlashAndStay(LED_Color_t targetColor)
{
    // Type 2: 記錄閃爍色
    // 重點：同時改變 g_StableColor，所以時間到會停在新的顏色
    g_FlashColor = targetColor;
    g_StableColor = targetColor; 
    g_IsFlashing = true;
    g_FlashStartTime = 0;
}

void LEDCtrl_Update(uint32_t current_time_ms)
{
    // 如果沒有在閃爍，確保硬體維持穩定色 (防止意外被改動)
    if (!g_IsFlashing) {
        // 選擇性優化：如果確定沒人會動 GPIO，這裡可以不一直寫入，省一點匯流排頻寬
        // 但為了強健性，持續寫入也是可以的
        return; 
    }

    // 如果剛開始閃爍 (由 API 設定為 0 觸發)
    if (g_FlashStartTime == 0) {
        g_FlashStartTime = current_time_ms;
        _HW_Write(g_FlashColor); // 立即亮起閃爍色
        return;
    }

    // 計算經過時間 (處理 Overflow 問題)
    uint32_t elapsed = current_time_ms - g_FlashStartTime;

    if (elapsed >= FLASH_DURATION_MS) {
        // 時間到 -> 結束閃爍
        g_IsFlashing = false;
        _HW_Write(g_StableColor); // 恢復成穩定色 (可能是舊的，也可能是新的)
    }
    // else: 還在時間內，保持閃爍色 (不用做動作)
}
