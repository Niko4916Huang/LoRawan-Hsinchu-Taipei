//*****************************************************************************
// sx1262_tm4c.c - TM4C1294 + SX1262 GFSK shared driver (TX + RX)
//
// FIXED per your requirements:
//  1) Command level: ALWAYS rely on BUSY pin (wait before + wait after each cmd)
//  2) Payload level: ONLY WriteBuffer/ReadBuffer add per-byte delay for FIFO timing
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#include "sx1262_tm4c.h"

#include "driverlib/ssi.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"

//------------------------------------------------------------------------------
// Tunable: FIFO per-byte delay (payload streaming only)
//------------------------------------------------------------------------------
#define SX1262_FIFO_BYTE_DELAY_US   (20U)   // <-- 先用 20us；不穩再加大 (30/50us)

//------------------------------------------------------------------------------
// SX1262 Command Opcodes
//------------------------------------------------------------------------------
#define SX1262_CMD_SET_SLEEP              0x84
#define SX1262_CMD_SET_STANDBY            0x80
#define SX1262_CMD_SET_FS                 0xC1
#define SX1262_CMD_SET_TX                 0x83
#define SX1262_CMD_SET_RX                 0x82
#define SX1262_CMD_SET_PACKET_TYPE        0x8A
#define SX1262_CMD_SET_RF_FREQUENCY       0x86
#define SX1262_CMD_SET_MODULATION_PARAMS  0x8B
#define SX1262_CMD_SET_PACKET_PARAMS      0x8C
#define SX1262_CMD_SET_BUFFER_BASE_ADDR   0x8F
#define SX1262_CMD_SET_TX_PARAMS          0x8E
#define SX1262_CMD_SET_PA_CONFIG          0x95
#define SX1262_CMD_SET_REGULATOR_MODE     0x96
#define SX1262_CMD_CLR_IRQ_STATUS         0x02
#define SX1262_CMD_WRITE_BUFFER           0x0E
#define SX1262_CMD_READ_BUFFER            0x1E
#define SX1262_CMD_WRITE_REGISTER         0x0D
#define SX1262_CMD_READ_REGISTER          0x1D
#define SX1262_CMD_GET_IRQ_STATUS         0x12
#define SX1262_CMD_GET_RX_BUFFER_STATUS   0x13
#define SX1262_CMD_GET_PACKET_STATUS      0x14
#define SX1262_CMD_GET_RSSI_INST       	  0x15
#define SX1262_CMD_SET_DIO_IRQ_PARAMS     0x08

//------------------------------------------------------------------------------
// IRQ bits (low 10 bits)
//------------------------------------------------------------------------------
#define SX1262_IRQ_TX_DONE         0x0001
#define SX1262_IRQ_RX_DONE         0x0002
#define SX1262_IRQ_CRC_ERR         0x0040
#define SX1262_IRQ_TIMEOUT         0x0200

//------------------------------------------------------------------------------
// GFSK / RF
//------------------------------------------------------------------------------
#define SX1262_PACKET_TYPE_GFSK            0x00

/* --------------------------------------------------------------------
 * RF frequency (SX1262 SetRfFrequency parameter = 4 bytes, MSB first)
 *  - RF Frequency = (FreqReg * FXOSC) / 2^25, FXOSC=32MHz
 *  - Here we keep pre-calculated FreqReg values as 4-byte tables.
 * ------------------------------------------------------------------*/
typedef struct
{
    uint32_t hz;
    uint8_t  reg[4];
} SX1262_RfFreqEntry_t;

static const SX1262_RfFreqEntry_t g_sx1262RfFreqTable[] =
{
    /* 915 MHz → FreqReg = 0x39300000 */
    { 915000000UL, { 0x39, 0x30, 0x00, 0x00 } },

    /* 400 MHz → FreqReg = 0x19000000 */
    { 400000000UL, { 0x19, 0x00, 0x00, 0x00 } },

    /* 204 MHz → FreqReg = 0x0CC00000 */
    { 204000000UL, { 0x0C, 0xC0, 0x00, 0x00 } },

    /* 255 MHz → FreqReg = 0x0FF00000 */
    { 255000000UL, { 0x0F, 0xF0, 0x00, 0x00 } },

    /* 257 MHz → FreqReg = 0x10100000 */
    { 257000000UL, { 0x10, 0x10, 0x00, 0x00 } },

    /* 490 MHz → FreqReg = 0x1EA00000 */
    { 490000000UL, { 0x1E, 0xA0, 0x00, 0x00 } },
	
	/* 833 MHz → FreqReg = 0x34100000 */
    { 833000000UL, { 0x34, 0x10, 0x00, 0x00 } },	
};

#define SX1262_RF_FREQ_TABLE_COUNT (sizeof(g_sx1262RfFreqTable)/sizeof(g_sx1262RfFreqTable[0]))

/* default selection (can be overridden from main.c via SX1262_SelectRfFrequency()) */
static volatile SX1262_RfFreqSel_t g_rfFreqSel = SX1262_RF_FREQ_915MHZ;

#define SX1262_TX_BASE_ADDR                0x00
#define SX1262_RX_BASE_ADDR                0x80

//------------------------------------------------------------------------------
// Static
//------------------------------------------------------------------------------
static uint32_t g_sysClockHz = 120000000UL;
static int8_t   g_txPowerDbm = 10;

//------------------------------------------------------------------------------
// Local helpers
//------------------------------------------------------------------------------
static void DelayUs(uint32_t us)
{
    // SysCtlDelay() 每次迴圈約 3 個 CPU cycle
    // cycles = sysClk * us / 1e6
    // loops  = cycles / 3
    uint32_t loops = (g_sysClockHz / 3000000U) * us;
    if (loops == 0) loops = 1;
    SysCtlDelay(loops);
}

static void SX1262_WaitOnBusy(void)
{
    while (SX1262_IS_BUSY())
    {
        // spin
    }
}

// 單 byte SPI 交換
static void SX1262_SpiTransferByte(uint8_t txByte, uint8_t *rxByte)
{
    uint32_t tmp;
    SSIDataPut(SX1262_SSI_BASE, txByte);
    SSIDataGet(SX1262_SSI_BASE, &tmp);
    if (rxByte)
        *rxByte = (uint8_t)tmp;
}

// 一般 buffer 傳輸（不加 per-byte delay：用於 command/register）
static void SX1262_SpiTransferBuffer(const uint8_t *tx, uint8_t *rx, uint16_t len)
{
    uint32_t tmp;
    uint16_t i;
    for (i = 0; i < len; i++)
    {
        uint8_t d = tx ? tx[i] : 0x00;
        SSIDataPut(SX1262_SSI_BASE, d);
        SSIDataGet(SX1262_SSI_BASE, &tmp);
        if (rx) rx[i] = (uint8_t)tmp;
    }
}

// Payload 串流（加 per-byte delay）：用於 FIFO read/write
static void SX1262_SpiTransferPayload_WithDelay(const uint8_t *tx, uint8_t *rx, uint16_t len)
{
    uint32_t tmp;
    uint16_t i;
    for (i = 0; i < len; i++)
    {
        uint8_t d = tx ? tx[i] : 0x00;
        SSIDataPut(SX1262_SSI_BASE, d);
        SSIDataGet(SX1262_SSI_BASE, &tmp);
        if (rx) rx[i] = (uint8_t)tmp;

        // 關鍵：每 byte 間隔，讓 SX1262 FIFO 有時間處理
        DelayUs(SX1262_FIFO_BYTE_DELAY_US);
    }
}

//------------------------------------------------------------------------------
// Command layer (BUSY handshake before + after each command)
//------------------------------------------------------------------------------
static void SX1262_WriteCommand(uint8_t opcode, const uint8_t *buffer, uint8_t size)
{
    SX1262_WaitOnBusy();
    SX1262_NSS_LOW();

    SX1262_SpiTransferByte(opcode, NULL);
    if (buffer && size)
        SX1262_SpiTransferBuffer(buffer, NULL, size);

    SX1262_NSS_HIGH();
    SX1262_WaitOnBusy();   // ★重要：確保本次 command 已被 SX1262 處理完
}

static void SX1262_ReadCommand(uint8_t opcode, uint8_t *buffer, uint8_t size)
{
    SX1262_WaitOnBusy();
    SX1262_NSS_LOW();

    SX1262_SpiTransferByte(opcode, NULL);
    SX1262_SpiTransferByte(0x00, NULL);     // dummy
    if (buffer && size)
        SX1262_SpiTransferBuffer(NULL, buffer, size);

    SX1262_NSS_HIGH();
    SX1262_WaitOnBusy();   // ★重要
}

static void SX1262_WriteRegister(uint16_t addr, const uint8_t *buffer, uint8_t size)
{
    uint8_t hdr[3];
    hdr[0] = SX1262_CMD_WRITE_REGISTER;
    hdr[1] = (uint8_t)(addr >> 8);
    hdr[2] = (uint8_t)(addr & 0xFF);

    SX1262_WaitOnBusy();
    SX1262_NSS_LOW();

    SX1262_SpiTransferBuffer(hdr, NULL, 3);
    if (buffer && size)
        SX1262_SpiTransferBuffer(buffer, NULL, size);

    SX1262_NSS_HIGH();
    SX1262_WaitOnBusy();   // ★重要（register write 也是 command）
}

static void SX1262_ReadRegister(uint16_t addr, uint8_t *buffer, uint8_t size)
{
    uint8_t hdr[4];
    hdr[0] = SX1262_CMD_READ_REGISTER;
    hdr[1] = (uint8_t)(addr >> 8);
    hdr[2] = (uint8_t)(addr & 0xFF);
    hdr[3] = 0x00;

    SX1262_WaitOnBusy();
    SX1262_NSS_LOW();

    SX1262_SpiTransferBuffer(hdr, NULL, 4);
    if (buffer && size)
        SX1262_SpiTransferBuffer(NULL, buffer, size);

    SX1262_NSS_HIGH();
    SX1262_WaitOnBusy();   // ★重要
}

//------------------------------------------------------------------------------
// Payload layer: FIFO access with per-byte delay
//------------------------------------------------------------------------------
static void SX1262_WriteBuffer(uint8_t offset, const uint8_t *buffer, uint8_t size)
{
    uint8_t hdr[2];
    hdr[0] = SX1262_CMD_WRITE_BUFFER;
    hdr[1] = offset;

    SX1262_WaitOnBusy();
    SX1262_NSS_LOW();

    SX1262_SpiTransferBuffer(hdr, NULL, 2);

    // ★關鍵：payload 每 byte 加 delay
    if (buffer && size)
        SX1262_SpiTransferPayload_WithDelay(buffer, NULL, size);

    SX1262_NSS_HIGH();
    SX1262_WaitOnBusy();   // ★重要
}

static void SX1262_ReadBuffer(uint8_t offset, uint8_t *buffer, uint8_t size)
{
    uint8_t hdr[3];
    hdr[0] = SX1262_CMD_READ_BUFFER;
    hdr[1] = offset;
    hdr[2] = 0x00;

    SX1262_WaitOnBusy();
    SX1262_NSS_LOW();

    SX1262_SpiTransferBuffer(hdr, NULL, 3);

    // ★關鍵：payload 每 byte 加 delay
    if (buffer && size)
        SX1262_SpiTransferPayload_WithDelay(NULL, buffer, size);

    SX1262_NSS_HIGH();
    SX1262_WaitOnBusy();   // ★重要
}

//------------------------------------------------------------------------------
// IRQ helpers
//------------------------------------------------------------------------------
static uint16_t SX1262_GetIrqStatus(void)
{
    uint8_t buf[2] = {0};
    SX1262_ReadCommand(SX1262_CMD_GET_IRQ_STATUS, buf, 2);
    return (uint16_t)((buf[0] << 8) | buf[1]) & 0x03FFU;
}

static void SX1262_ClearAllIrq(void)
{
    uint8_t buf[2] = { 0xFF, 0xFF };
    SX1262_WriteCommand(SX1262_CMD_CLR_IRQ_STATUS, buf, 2);
}

static void SX1262_SetDioIrqParams(uint16_t irqMask,
                                  uint16_t dio1Mask,
                                  uint16_t dio2Mask,
                                  uint16_t dio3Mask)
{
    uint8_t buf[8];
    buf[0] = (uint8_t)(irqMask >> 8);
    buf[1] = (uint8_t)(irqMask & 0xFF);
    buf[2] = (uint8_t)(dio1Mask >> 8);
    buf[3] = (uint8_t)(dio1Mask & 0xFF);
    buf[4] = (uint8_t)(dio2Mask >> 8);
    buf[5] = (uint8_t)(dio2Mask & 0xFF);
    buf[6] = (uint8_t)(dio3Mask >> 8);
    buf[7] = (uint8_t)(dio3Mask & 0xFF);

    SX1262_WriteCommand(SX1262_CMD_SET_DIO_IRQ_PARAMS, buf, 8);
}

//------------------------------------------------------------------------------
// Reset / basic RF config
//------------------------------------------------------------------------------
static void SX1262_Reset(void)
{
    GPIOPinWrite(SX1262_NRESET_PORT, SX1262_NRESET_PIN, 0);
    SysCtlDelay(g_sysClockHz / (3 * 1000));  // ~1ms

    GPIOPinWrite(SX1262_NRESET_PORT, SX1262_NRESET_PIN, SX1262_NRESET_PIN);
    SysCtlDelay(g_sysClockHz / (3 * 1000));  // ~1ms
}

static void SX1262_SetStandbyRC(void)
{
    uint8_t buf = 0x00;
    SX1262_WriteCommand(SX1262_CMD_SET_STANDBY, &buf, 1);
}

static void SX1262_SetRegulatorModeDcdc(void)
{
    uint8_t buf = 0x01; // 1=DCDC
    SX1262_WriteCommand(SX1262_CMD_SET_REGULATOR_MODE, &buf, 1);
}

static void SX1262_SetPacketTypeGFSK(void)
{
    uint8_t buf = SX1262_PACKET_TYPE_GFSK;
    SX1262_WriteCommand(SX1262_CMD_SET_PACKET_TYPE, &buf, 1);
}

/* Select one of the pre-defined RF frequency entries and write to radio */
void SX1262_SetRfFrequency(SX1262_RfFreqSel_t sel)
{
    if ((uint32_t)sel >= (uint32_t)SX1262_RF_FREQ_TABLE_COUNT)
    {
        sel = SX1262_RF_FREQ_915MHZ;
    }

    SX1262_WriteCommand(SX1262_CMD_SET_RF_FREQUENCY,
                        (uint8_t*)g_sx1262RfFreqTable[(uint32_t)sel].reg,
                        4);
}

/* Set the default RF frequency used during SX1262_Init() */
void SX1262_SelectRfFrequency(SX1262_RfFreqSel_t sel)
{
    if ((uint32_t)sel >= (uint32_t)SX1262_RF_FREQ_TABLE_COUNT)
    {
        sel = SX1262_RF_FREQ_915MHZ;
    }
    g_rfFreqSel = sel;
}

/* Backward-compatible helper (kept as static, used only if older code calls it) */
static void SX1262_SetRfFrequency915MHz(void)
{
    SX1262_SetRfFrequency(SX1262_RF_FREQ_915MHZ);
}


static void SX1262_SetBufferBaseAddress(void)
{
    uint8_t buf[2];
    buf[0] = SX1262_TX_BASE_ADDR;
    buf[1] = SX1262_RX_BASE_ADDR;
    SX1262_WriteCommand(SX1262_CMD_SET_BUFFER_BASE_ADDR, buf, 2);
}

static void SX1262_SetPaConfig(void)
{
    uint8_t buf[4] = { 0x04, 0x07, 0x00, 0x01 };
    SX1262_WriteCommand(SX1262_CMD_SET_PA_CONFIG, buf, 4);
}

static void SX1262_SetTxParamsInternal(int8_t dbm, uint8_t rampCode)
{
    if (dbm < -9)  dbm = -9;
    if (dbm > 22) dbm = 22;

    uint8_t buf[2];
    buf[0] = (uint8_t)dbm;
    buf[1] = rampCode;  // 0x05=800us
    SX1262_WriteCommand(SX1262_CMD_SET_TX_PARAMS, buf, 2);
	/* ★你要求：在 SetTxParams 後延遲 1ms */
   // DelayUs(1000);
}

void SX1262_SetTxPowerDbm(int8_t dbm)
{
    g_txPowerDbm = dbm;
    SX1262_SetTxParamsInternal(g_txPowerDbm, 0x06);
}

static void SX1262_SetModulationParamsGFSK(void)
{
    // 你目前的設定照保留（可後續再精算）
    //const uint32_t bitRateReg = 0x00000280;
	//const uint32_t bitRateReg = 0x00000C80;
	const uint32_t bitRateReg = 0x0000D055;
	//const uint32_t bitRateReg = 0x01A0AB; // 300BPS/
	
    //const uint32_t fdevReg    = 0x006666;
	const uint32_t fdevReg    = 0x00147B;   //5k FDEV/ / 600BPS//
	//const uint32_t fdevReg    = 0x000831;   //2k FDEV/ / 300BPS/

    uint8_t buf[8];
    buf[0] = (uint8_t)(bitRateReg >> 16);
    buf[1] = (uint8_t)(bitRateReg >> 8);
    buf[2] = (uint8_t) bitRateReg;
	
	buf[3] = 0x09; // BT=0.5
    //buf[4] = 0x0A; // RxBW code (你原本選 234k 的路線)
	buf[4] = 0x09; // RxBW code (你原本選 467k 的路線)
	
    buf[5] = (uint8_t)(fdevReg >> 16);
    buf[6] = (uint8_t)(fdevReg >> 8);
    buf[7] = (uint8_t) fdevReg;
	



    SX1262_WriteCommand(SX1262_CMD_SET_MODULATION_PARAMS, buf, 8);
}

static void SX1262_SetPacketParamsGFSK(uint8_t payloadLen)
{
    uint8_t buf[9];

    uint16_t preambleBits = 32;
    buf[0] = (uint8_t)(preambleBits >> 8);
    buf[1] = (uint8_t)(preambleBits >> 0x00);
	//buf[1] = (uint8_t)(preambleBits & 0xFF);

    buf[2] = 0x04;   // preamble detector (依你原設定保留)
   
    buf[3] = 16;   // sync word length
    buf[4] = 0x00;   // addr filter off
    buf[5] = 0x00;   // fixed length
    buf[6] = payloadLen;
    buf[7] = 0x01;   // no CRC
    buf[8] = 0x00;   // whitening enable(你原本設定)

    SX1262_WriteCommand(SX1262_CMD_SET_PACKET_PARAMS, buf, 9);
}

static void SX1262_ConfigGFSKSyncWord(void)
{
    uint8_t sync[8] = { 0xBE, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    SX1262_WriteRegister(0x06C0, sync, 8);
}

static void UART_PrintFrameHex(const char* tag, const uint8_t* buf, uint32_t len)
{
    UARTprintf("%s len=%u\r\n", tag, (unsigned)len);
    uint32_t i;
	for (i = 0; i < len; i++)
    {
        if ((i & 0x0F) == 0)
        {
            UARTprintf("%03u: ", (unsigned)i);
        }
        UARTprintf("%02X ", buf[i]);
        if (((i & 0x0F) == 0x0F) || (i == (len - 1)))
        {
            UARTprintf("\r\n");
        }
    }
}


static void SX1262_PrintTxFifoFrame(uint8_t length)
{
    uint8_t fifo[128];

    if (length == 0 || length > sizeof(fifo))
    {
        UARTprintf("[TX FIFO] invalid length=%u\r\n", (unsigned)length);
        return;
    }

    SX1262_ReadBuffer(SX1262_TX_BASE_ADDR, fifo, length);

  //  UART_PrintFrameHex("[TX FIFO FRAME]", fifo, length);
}


//------------------------------------------------------------------------------
// Public: RSSI
//------------------------------------------------------------------------------
int16_t SX1262_ReadPacketRssi(void)
{
    uint8_t buf[3] = {0};
    SX1262_ReadCommand(SX1262_CMD_GET_PACKET_STATUS, buf, 3);

    // 你之前改用 buf[2]：這裡照你的
    uint8_t pktRssi = buf[1];
    return -((int16_t)pktRssi / 2);
}

int16_t SX1262_ReadInstantRssi(void)
{
    uint8_t rssiRaw = 0;

    /* Get instantaneous RSSI */
    SX1262_ReadCommand(SX1262_CMD_GET_RSSI_INST, &rssiRaw, 1);

    /* RSSI(dBm) = -rssiRaw / 2 */
    return -((int16_t)rssiRaw / 2);
}


//------------------------------------------------------------------------------
// Public: Init
//------------------------------------------------------------------------------
void SX1262_Init(uint32_t sysClockHz)
{
    g_sysClockHz = sysClockHz;

    SysCtlPeripheralEnable(SX1262_BUSY_PERIPH);
    SysCtlPeripheralEnable(SX1262_NRESET_PERIPH);
    SysCtlPeripheralEnable(SX1262_DIO1_PERIPH);
    SysCtlPeripheralEnable(SX1262_DIO2_PERIPH);
    SysCtlPeripheralEnable(SX1262_ANTSW_PERIPH);

    SysCtlPeripheralEnable(SX1262_SCK_PERIPH);
    SysCtlPeripheralEnable(SX1262_NSS_PERIPH);
    SysCtlPeripheralEnable(SX1262_MOSI_PERIPH);
    SysCtlPeripheralEnable(SX1262_MISO_PERIPH);
    SysCtlPeripheralEnable(SX1262_SSI_PERIPH);

    while (!SysCtlPeripheralReady(SX1262_SSI_PERIPH))
    {
    }

    GPIOPinTypeGPIOInput(SX1262_BUSY_PORT, SX1262_BUSY_PIN);

    GPIOPinTypeGPIOOutput(SX1262_NRESET_PORT, SX1262_NRESET_PIN);
    GPIOPinWrite(SX1262_NRESET_PORT, SX1262_NRESET_PIN, SX1262_NRESET_PIN);

    GPIOPinTypeGPIOInput(SX1262_DIO1_PORT, SX1262_DIO1_PIN);
    GPIOPinTypeGPIOInput(SX1262_DIO2_PORT, SX1262_DIO2_PIN);

    GPIOPinTypeGPIOOutput(SX1262_ANTSW_PORT, SX1262_ANTSW_PIN);
    SX1262_ANTSW_RX();

    GPIOPinTypeGPIOOutput(SX1262_NSS_PORT, SX1262_NSS_PIN);
    SX1262_NSS_HIGH();

    // SSI1 pins
    GPIOPinConfigure(GPIO_PB5_SSI1CLK);
    GPIOPinConfigure(GPIO_PE4_SSI1XDAT0);
    GPIOPinConfigure(GPIO_PE5_SSI1XDAT1);

    GPIOPinTypeSSI(SX1262_SCK_PORT,  SX1262_SCK_PIN);
    GPIOPinTypeSSI(SX1262_MOSI_PORT, SX1262_MOSI_PIN);
    GPIOPinTypeSSI(SX1262_MISO_PORT, SX1262_MISO_PIN);

    SSIConfigSetExpClk(SX1262_SSI_BASE,
                       g_sysClockHz,
                       SSI_FRF_MOTO_MODE_0,
                       SSI_MODE_MASTER,
                       8000000,
                       8);
    SSIEnable(SX1262_SSI_BASE);

    // Reset + config
    SX1262_Reset();
    SX1262_SetStandbyRC();
    SX1262_SetRegulatorModeDcdc();
    SX1262_SetPacketTypeGFSK();
    SX1262_SetRfFrequency(g_rfFreqSel);
    SX1262_SetBufferBaseAddress();
    SX1262_SetPaConfig();
    SX1262_SetTxPowerDbm(10);
    SX1262_SetModulationParamsGFSK();
    SX1262_ConfigGFSKSyncWord();

    SX1262_SetStandbyRC();
    SX1262_ANTSW_RX();
}

//------------------------------------------------------------------------------
// Public: TX (blocking)
//------------------------------------------------------------------------------
bool SX1262_TransmitBlocking(const uint8_t *data, uint8_t length)
{
    if (!data || length == 0)
        return;

    SX1262_ANTSW_TX();

    SX1262_SetTxParamsInternal(g_txPowerDbm, 0x05);
    SX1262_SetPacketParamsGFSK(length);

    // FIFO write with per-byte delay inside
    SX1262_WriteBuffer(SX1262_TX_BASE_ADDR, data, length);
	
	  /* 2. 讀回 + 印出 TX FIFO FRAME（你要的重點） */
    SX1262_PrintTxFifoFrame(128);

    SX1262_ClearAllIrq();
    SX1262_SetStandbyRC();

    uint16_t irqMask = SX1262_IRQ_TX_DONE | SX1262_IRQ_TIMEOUT;
    SX1262_SetDioIrqParams(irqMask, irqMask, 0, 0);

    // 200ms timeout in 15.625us unit -> 12800
    uint32_t t = 12800U;
    uint8_t buf[3] = { (uint8_t)(t >> 16), (uint8_t)(t >> 8), (uint8_t)t };
    SX1262_WriteCommand(SX1262_CMD_SET_TX, buf, 3);

    uint32_t loopMax = g_sysClockHz / 10000U;
    while (loopMax--)
    {
        uint16_t irq = SX1262_GetIrqStatus();
        if (irq & (SX1262_IRQ_TX_DONE | SX1262_IRQ_TIMEOUT))
            break;
    }
	
	uint16_t irq = SX1262_GetIrqStatus();

/* 	if (irq & SX1262_IRQ_TX_DONE)
	{
		UARTprintf("[TX] TX_DONE OK\r\n");
	}
	else if (irq & SX1262_IRQ_TIMEOUT)
	{
		UARTprintf("[TX] TX TIMEOUT !!\r\n");
	} */


    SX1262_ClearAllIrq();
    SX1262_SetStandbyRC();
    SX1262_ANTSW_RX();
}

//------------------------------------------------------------------------------
// Public: RX (blocking)
//------------------------------------------------------------------------------
bool SX1262_ReceiveBlocking(uint8_t *data,
                            uint8_t  maxLen,
                            uint8_t *outLen,
                            uint32_t timeoutMs)
{
    if (!data || maxLen == 0)
    {
        if (outLen) *outLen = 0;
        return false;
    }

    SX1262_ANTSW_RX();

    SX1262_SetPacketParamsGFSK(maxLen);
    SX1262_SetBufferBaseAddress();
    SX1262_ClearAllIrq();
    SX1262_SetStandbyRC();

    uint16_t irqMask = SX1262_IRQ_RX_DONE | SX1262_IRQ_TIMEOUT | SX1262_IRQ_CRC_ERR;
    SX1262_SetDioIrqParams(irqMask, irqMask, 0, 0);

    uint32_t t = timeoutMs * 64U;
    if (t > 0xFFFFFFUL) t = 0xFFFFFFUL;

    uint8_t tbuf[3] = { (uint8_t)(t >> 16), (uint8_t)(t >> 8), (uint8_t)t };
    SX1262_WriteCommand(SX1262_CMD_SET_RX, tbuf, 3);

    uint32_t loopMax = timeoutMs * (g_sysClockHz / 1000U / 200U);
    if (loopMax == 0) loopMax = g_sysClockHz / 10000U;

    uint16_t irq = 0;
    while (loopMax--)
    {
        irq = SX1262_GetIrqStatus();
        if (irq & (SX1262_IRQ_RX_DONE | SX1262_IRQ_TIMEOUT | SX1262_IRQ_CRC_ERR))
            break;
    }

    SX1262_ClearAllIrq();

    if (!(irq & SX1262_IRQ_RX_DONE) || (irq & SX1262_IRQ_CRC_ERR))
    {
        if (outLen) *outLen = 0;
        SX1262_SetStandbyRC();
        SX1262_ANTSW_RX();
        return false;
    }

    uint8_t st[2] = {0};
    SX1262_ReadCommand(SX1262_CMD_GET_RX_BUFFER_STATUS, st, 2);
    uint8_t payloadLen = st[0];
    uint8_t startPtr   = st[1];

    if (payloadLen > maxLen) payloadLen = maxLen;

    // FIFO read with per-byte delay inside
    SX1262_ReadBuffer(startPtr, data, payloadLen);

    if (outLen) *outLen = payloadLen;

    SX1262_SetStandbyRC();
    SX1262_ANTSW_RX();
    return true;
}
