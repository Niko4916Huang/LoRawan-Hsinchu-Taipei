/*
 * ledctrl.h
 *
 * Created on: 2025/11/23
 * Author: Addison
 * Description: Non-blocking LED Controller for Transponder Board
 * Pinout: PM6 (Red), PM7 (Green)
 */

#ifndef LEDCTRL_H_
#define LEDCTRL_H_

#include <stdint.h>
#include <stdbool.h>

// 定義顏色列舉
typedef enum {
    LED_OFF = 0,    // 滅燈
    LED_RED,        // 紅色 (B)
    LED_GREEN,      // 綠色 (A) 
    LED_YELLOW      // 黃色 (C, 紅+綠)      ***黃燈效果不好, 不建議使用*** [Tested] 
} LED_Color_t;

// --- 系統初始化與更新 ---
// 初始化 GPIO (PM6, PM7)
void LEDCtrl_Init(void);

// 狀態機更新函式，請在 main loop 中持續呼叫
// current_time_ms: 系統目前的毫秒數 (systick)
void LEDCtrl_Update(uint32_t current_time_ms);


// --- 功能控制 API ---

// 1. 設定恆亮 (Solid)
// 直接改變燈號，不會閃爍
void LEDCtrl_SetSolid(LED_Color_t color);

// 2. 閃爍 Type 1 (Restore): A1, B1, C1
// 亮起指定顏色 200ms，結束後「恢復原本」的燈號
void LEDCtrl_FlashAndRestore(LED_Color_t flashColor);

// 3. 閃爍 Type 2 (Stay): A2, B2, C2
// 亮起指定顏色 200ms，結束後「持續維持」該燈號 (改變狀態)
void LEDCtrl_FlashAndStay(LED_Color_t targetColor);

#endif /* LEDCTRL_H_ */
